package com.gcp.controller;

import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gcp.dto.CreateUserDTO;
import com.gcp.dto.UpdateUserDTO;
import com.gcp.pojo.adminpanel.Role;
import com.gcp.pojo.adminpanel.UserDataTable;
import com.gcp.pojo.validation.Validation;
import com.gcp.service.AdminService;

@RestController
public class AdminRestController {

	@Autowired
	AdminService adminService;

	@RequestMapping(value = { "/listroles" }, method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<Role>> listRoles() {
		try {
			List<Role> roles = adminService.listRoles();
			return ResponseEntity.status(HttpStatus.OK).body(roles);
		} catch (Exception e) {
			e.printStackTrace(System.err);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@RequestMapping(value = { "/listusers" }, method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<HashMap<String,List<UserDataTable>>> listusers() {
		try {
			
			List<UserDataTable> users = adminService.listUsers();
			HashMap<String,List<UserDataTable>> result = new HashMap<String,List<UserDataTable>>(){{
				put("data",users);
			}};
			return ResponseEntity.status(HttpStatus.OK).body(result);
		} catch (Exception e) {
			e.printStackTrace(System.err);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@RequestMapping(value = { "/validatepsid" }, method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<Validation> validatePsId(@RequestParam String psId) {
		try {
			if (psId.equals("wrongid")) {
				return ResponseEntity.status(HttpStatus.OK).body(new Validation(false, "InValid ID"));
			} else {
				return ResponseEntity.status(HttpStatus.OK)
						.body(new Validation(true, "The ID has been validated successfully with Active Directory"));
			}

		} catch (Exception e) {
			e.printStackTrace(System.err);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

	@RequestMapping(value = { "/createuser" }, method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> createUser(@Valid CreateUserDTO createUserDto) {
		try {
			if (adminService.createUser(createUserDto)) {
				return ResponseEntity.status(HttpStatus.OK).build();
			}else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
			}
		} catch (Exception e) {
			e.printStackTrace(System.err);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}
	
	@RequestMapping(value = { "/updateuser" }, method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<?> updateuser(@Valid UpdateUserDTO updateUserDto) {
		try {
			if (adminService.updateUser(updateUserDto)) {
				return ResponseEntity.status(HttpStatus.OK).build();
			}else {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
			}
		} catch (Exception e) {
			e.printStackTrace(System.err);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}

}