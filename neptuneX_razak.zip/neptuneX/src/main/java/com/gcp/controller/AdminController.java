package com.gcp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.gcp.service.AdminService;
import com.gcp.service.MainService;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.util.ArrayList;

@Controller
public class AdminController {

	@Autowired
	AdminService adminService;
	
	@RequestMapping(value = { "/project_management" }, method = RequestMethod.GET)
	public ModelAndView project_management() {
		return new ModelAndView("/admin_portal/project_management");
	}
	
	@RequestMapping(value = { "/role_management" }, method = RequestMethod.GET)
	public ModelAndView role_management() {
		return new ModelAndView("/admin_portal/role_management");
	}
	
	@RequestMapping(value = { "/user_management" }, method = RequestMethod.GET)
	public ModelAndView user_management() {
		return new ModelAndView("/admin_portal/user_management");
	}
	
	
	@RequestMapping(value = { "/createRole" }, method = RequestMethod.POST)
	public @ResponseBody String createRole(@ModelAttribute("roleName") String roleName, @ModelAttribute("schema") String schema[]) {
		
		    boolean status = adminService.createRole(roleName, schema);
			
			return "Created";
		

	}
	
	@RequestMapping(value = { "/modifyRole" }, method = RequestMethod.POST)
	public @ResponseBody String modifyRole(@ModelAttribute("roleName") String roleName, @ModelAttribute("schema") String schema[]) {
		
		    boolean status = adminService.modifyRole(roleName, schema);
			
			return "Updated";
		

	}
	
	@RequestMapping(value = { "/getRoleNames" }, method = RequestMethod.GET)
	public @ResponseBody String getRoleNames() {

		try {
			HashMap roleNm = adminService.getRoleNames();
			
			String json = new Gson().toJson(roleNm);
			return json;
		} catch (Exception e) {
			e.printStackTrace(System.err);
			return null;
		}
	}
	
	
	@RequestMapping(value = { "/getFeatures/{roleId}" }, method = RequestMethod.GET)
	public @ResponseBody String getFeatures(@PathVariable int roleId) {

		try {
			List featuresNm = adminService.getFeatures(roleId);
			System.out.println("features "+featuresNm);
			//Map<String, List<String>> map = new HashMap<String, List<String>>();
			//map.put("features", featuresNm);
			String json = new Gson().toJson(featuresNm);
			return json;
		} catch (Exception e) {
			e.printStackTrace(System.err);
			return null;
		}
	}
	
	@RequestMapping(value = { "/approve_model" }, method = RequestMethod.GET)
	public ModelAndView approve_model() {
		try {
			ModelAndView modelView = new ModelAndView();

			List<String> modelType = adminService.getModelType();
			modelView.setViewName("/admin_portal/approve_model");
			Map<String, List<String>> map = new HashMap<String, List<String>>();
			map.put("modelType", modelType);

			String json = new Gson().toJson(map);
			modelView.addObject("modelType", json);
			return modelView;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace(System.err);
			return null;
		}
		/*return new ModelAndView("/admin_portal/approve_model");*/
	}
	
	@RequestMapping(value = { "/getAdminModelNm" }, method = RequestMethod.GET)
	public @ResponseBody String getModelNm(@ModelAttribute("modelType") String modelType, ModelMap modelMap, HttpServletRequest request) {

		try {
			List<String> modelNm = adminService.getModelName(modelType);
			System.out.println("get");
			Map<String, List<String>> map = new HashMap<String, List<String>>();
			map.put("modelNm", modelNm);
			String json = new Gson().toJson(map);
			return json;
		} catch (Exception e) {
			e.printStackTrace(System.err);
			return null;
		}
	}
	
	@RequestMapping(value = { "/getModelAdminVr" }, method = RequestMethod.GET)
	public @ResponseBody String getModelVr(@ModelAttribute("modelType") String modelType, @ModelAttribute("modelName") String modelName, ModelMap modelMap, HttpServletRequest request) 
	{

		try {

			List<String> modelVr = adminService.getModelVer(modelType, modelName);
			Map<String, List<String>> map = new HashMap<String, List<String>>();
			map.put("modelVr", modelVr);
			String json = new Gson().toJson(map);
			return json;
		} catch (Exception e) {
			e.printStackTrace(System.err);
			return null;
		}
	}
	
	@RequestMapping(value = { "/publishAdminModel" }, method = RequestMethod.GET)
	public @ResponseBody boolean publishModel(@ModelAttribute("modelType") String modelType, @ModelAttribute("modelName") String modelName, @ModelAttribute("modelVer") int modelVer,@ModelAttribute("check") String check
			) {
		try {
			// boolean status=true;
			System.out.print("inside publishmodel");
			System.out.println("from jsp"+check);
			boolean status = adminService.publishModel(modelType, modelName, modelVer,check );
			return status;
		} catch (Exception e) {
			e.printStackTrace(System.err);
			return false;
		}
	}	
	
	@RequestMapping(value = { "/createProject" }, method = RequestMethod.POST)
	public @ResponseBody String createProject(@ModelAttribute("projectNm") String projectNm, @ModelAttribute("projectDesc") String projectDesc, @ModelAttribute("projOwner") String projOwner,@ModelAttribute("g_projNm") String g_projNm,@ModelAttribute("g_projdesc") String g_projdesc,@ModelAttribute("G_projOwner") String G_projOwner) throws Exception {
		 String msg=null;
	     boolean status=adminService.checkProjectName(g_projNm);
	     System.out.println("status : "+status);
	     if(status)
	     {
		   
		    adminService.createProject(projectNm, projectDesc,projOwner,g_projNm,g_projdesc,G_projOwner);
		    Process process = Runtime.getRuntime().exec("ssh 34.76.254.41 bash createProject.sh " + projectNm + " " + projectDesc +" " +  projOwner + " " + g_projNm +" " +  g_projdesc +" " +  G_projOwner);
		     
	     }
	     msg=(status==true)?"Values Successfully Created":"Google Project name not exists";
	     
		return msg;
	}
	
	@RequestMapping(value = { "/updateProject/{KprojectId}" }, method = RequestMethod.POST)
	public @ResponseBody String updateProject(@PathVariable int KprojectId, @ModelAttribute("projectNm") String projectNm, @ModelAttribute("projectDesc") String projectDesc, @ModelAttribute("projOwner") String projOwner,@ModelAttribute("g_projNm") String g_projNm,@ModelAttribute("g_projdesc") String g_projdesc,@ModelAttribute("G_projOwner") String G_projOwner) throws Exception {
		     String msg=null;
		     boolean status=adminService.checkProjectName(g_projNm);
		     System.out.println("status : "+status);
		     if(status)
		     {
		     
		     adminService.updateProject(KprojectId,projectNm, projectDesc,projOwner,g_projNm,g_projdesc,G_projOwner);
		     Process process = Runtime.getRuntime().exec("ssh 34.76.254.41 bash createProject.sh " + projectNm + " " + projectDesc +" " +  projOwner + " " + g_projNm +" " +  g_projdesc +" " +  G_projOwner);
		     
		     }
		     msg=(status==true)?"Values Successfully updated":"Google Project name not exists";
		     
			return msg;
	}
	
	
	

	@RequestMapping(value = { "/getProjectNames" }, method = RequestMethod.GET)
	public @ResponseBody String getProjectNames() {

		try {
			HashMap roleNm = adminService.getProjectNames();
			
			String json = new Gson().toJson(roleNm);
			return json;
		} catch (Exception e) {
			e.printStackTrace(System.err);
			return null;
		}
	}
	
	
	
	
	
	@RequestMapping(value = { "/getProjectdetails/{projId}" }, method = RequestMethod.GET)
	public @ResponseBody String getProjectdetails(@PathVariable int projId) {

		try {
			HashMap projMap = adminService.getProjectdetails(projId);
			String json = new Gson().toJson(projMap);
			return json;
		} catch (Exception e) {
			e.printStackTrace(System.err);
			return null;
		}
	}
	
}