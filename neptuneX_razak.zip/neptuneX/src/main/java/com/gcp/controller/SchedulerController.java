package com.gcp.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.gcp.service.MainService;
import com.google.gson.Gson;

@Controller
public class SchedulerController {

	@Autowired
	MainService mainService;
	
	@RequestMapping(value = { "/create_batch" }, method = RequestMethod.GET)
	public ModelAndView create_batch() {
		try {
			ModelAndView modelView = new ModelAndView();

			List<String> modelType = mainService.getModelType();
			modelView.setViewName("/model_schedule/create_batch");
			Map<String, List<String>> map = new HashMap<String, List<String>>();
			map.put("modelType", modelType);

			String json = new Gson().toJson(map);
			modelView.addObject("modelType", json);
			return modelView;

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace(System.err);
			return null;
		}
	}
	
	@RequestMapping(value = { "/schedule_batch" }, method = RequestMethod.GET)
	public ModelAndView schedule_batch() {
		return new ModelAndView("/model_schedule/schedule_batch");
	}

	@RequestMapping(value = { "/batch_progress" }, method = RequestMethod.GET)
	public ModelAndView batch_progress() {
		return new ModelAndView("/model_schedule/batch_progress");
	}
}