package com.gcp.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.gcp.service.MainService;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.compute.Compute;
import com.google.api.services.compute.model.Address;
import com.google.api.services.compute.model.AddressList;
import com.google.api.services.compute.model.Image;
import com.google.api.services.compute.model.ImageList;

@Controller
public class MainController {

	@Autowired
	MainService mainService;

	@Value("${gcp.project}")
	private String gcp_project;
	
	@Value("${neptuneX.script.path}")
	private String scriptPath;
	
	@Value("${neptuneX.servieacc.path}")
	private String servAccPath;
	

	@RequestMapping(value = { "/" }, method = RequestMethod.GET)
	public String homePage() throws Exception {

		return "/index";
	}

	@RequestMapping(value = { "/userlogin" }, method = RequestMethod.POST)
	public ModelAndView userlogin(@Valid @ModelAttribute("username") String username,
			@Valid @ModelAttribute("password") String password) {
		if (username.equalsIgnoreCase("admin") && password.equalsIgnoreCase("admin"))
			return new ModelAndView("/home");
		else
			return new ModelAndView("/index");
	}

	@RequestMapping(value = { "/userlogout" }, method = RequestMethod.GET)
	public ModelAndView userlogout() {
		return new ModelAndView("/index");
	}

	@RequestMapping(value = { "/home" }, method = RequestMethod.GET)
	public ModelAndView home() {
		return new ModelAndView("/home");
	}

	@RequestMapping(value = { "/user_access" }, method = RequestMethod.GET)
	public ModelAndView user_access() {
		return new ModelAndView("terraform/user_access");
	}

	@RequestMapping(value = { "/project_create" }, method = RequestMethod.GET)
	public ModelAndView projectcreate() {
		return new ModelAndView("terraform/project_create");
	}

	@RequestMapping(value = { "/compute_create" }, method = RequestMethod.GET)
	public ModelAndView computecreate(@Valid final ModelMap model, final HttpServletRequest request) {
		try {
		ArrayList<String> imageList = fetchImageList();
		model.addAttribute("imageList",imageList);
		}catch (Exception e) {
			e.printStackTrace();
		}
		return new ModelAndView("terraform/compute_create");
	}

	@RequestMapping(value = { "/image" }, method = RequestMethod.POST)
	public @ResponseBody boolean image(@ModelAttribute("image") String image,@ModelAttribute("Name") String Name, 
			@ModelAttribute("type") String type,@ModelAttribute("region") String region,@ModelAttribute("fireWall") String fireWall,@ModelAttribute("lKey") String lKey,@ModelAttribute("lValue") String lValue ) {

		try {
			
			/*
			 * ModelAndView modelView = new ModelAndView(); Runtime run=
			 * Runtime.getRuntime(); System.out.println("running bash"); Process
			 * pr=run.exec("sh "+scriptPath+"run.sh "+image+" "+Name+" "+type+" "+region+" "
			 * +fireWall+" "+lKey+" "+lValue); System.out.println("done");
			 */
			
			return true;
		} catch (Exception e) {
			e.printStackTrace(System.err);
			return false;
		}

	}
	
	@RequestMapping(value = { "/address" }, method = RequestMethod.POST)
	public @ResponseBody String getAddress(@ModelAttribute("Name") String Name,@ModelAttribute("Region") String Region) {
			String address="";
		try {
			System.out.println("get address");
			Thread.sleep(10000);
			address = fetchIPOfCompute(gcp_project,Name,Region);
			return address;
		} catch (Exception e) {
			e.printStackTrace(System.err);
			return address;
		}
	}
	
	public String fetchIPOfCompute(String projectId,String computeName,String Region) {
		String externalIP = "";
		try {
			Compute computeService = createComputeService();
			System.out.println("computeName--"+computeName);
			System.out.println("projectId--"+projectId);
			System.out.println("eg--"+(Region.split("-")[0]+"-"+Region.split("-")[1]));
			Compute.Addresses.List request1 = computeService.addresses().list(projectId, Region.split("-")[0]+"-"+Region.split("-")[1]);

		    AddressList response1;
		    do {
		      response1 = request1.execute();
		      if (response1.getItems() == null) {
		        continue;
		      }
		      for (Address address : response1.getItems()) {
		        // TODO: Change code below to process each `address` resource:
		    	  System.out.println("address.getName()--"+address.getName());
		    	  if(address.getName().equalsIgnoreCase(computeName)) {
		    		  
		    		  externalIP = address.getAddress();
		    		  break;
		    	  }
		      }
		      request1.setPageToken(response1.getNextPageToken());
		    } while (response1.getNextPageToken() != null);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return externalIP;
		
	}
	
	public ArrayList<String> fetchImageList(){
		ArrayList<String> imageList = null;
		try {
			String project = "iig-infosys";
			Compute computeService = createComputeService();
		    Compute.Images.List request = computeService.images().list(project);
		    
		    ImageList response;
		    do {
		      response = request.execute();
		      if (response.getItems() == null) {
		        continue;
		      }
		      imageList = new ArrayList<String>();
		      for (Image image : response.getItems()) {
		    	  imageList.add(image.getName());
		      }
		      request.setPageToken(response.getNextPageToken());
		    } while (response.getNextPageToken() != null);
		}catch(Exception e) {
			
		}
		return imageList;
	}

	
	public  Compute createComputeService() throws IOException, GeneralSecurityException {
	    HttpTransport httpTransport = GoogleNetHttpTransport.newTrustedTransport();
	    JsonFactory jsonFactory = JacksonFactory.getDefaultInstance();
	    GoogleCredential credential = null;
	    
	   // try (InputStream resourceAsStream = new FileInputStream(servAccPath)) {
	     try (InputStream resourceAsStream = new FileInputStream("iig-infosys-c0b53aea732d.json")) {
	    	 credential =GoogleCredential.fromStream(resourceAsStream);
	     }
	   
	    if (credential.createScopedRequired()) {
	      credential =
	          credential.createScoped(Arrays.asList("https://www.googleapis.com/auth/cloud-platform"));
	    }
	    return new Compute.Builder(httpTransport, jsonFactory, credential)
	        .setApplicationName("Google-ComputeSample/0.1")
	        .build();
	  }
}