package com.gcp;

/*
 * BEFORE RUNNING:
 * ---------------
 * 1. If not already done, enable the Compute Engine API
 *    and check the quota for your project at
 *    https://console.developers.google.com/apis/api/compute
 * 2. This sample uses Application Default Credentials for authentication.
 *    If not already done, install the gcloud CLI from
 *    https://cloud.google.com/sdk and run
 *    `gcloud beta auth application-default login`.
 *    For more information, see
 *    https://developers.google.com/identity/protocols/application-default-credentials
 * 3. Install the Java client library on Maven or Gradle. Check installation
 *    instructions at https://github.com/google/google-api-java-client.
 *    On other build systems, you can add the jar files to your project from
 *    https://developers.google.com/resources/api-libraries/download/compute/v1/java
 */

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.compute.Compute;
import com.google.api.services.compute.model.Address;
import com.google.api.services.compute.model.AddressList;
import com.google.api.services.compute.model.Image;
import com.google.api.services.compute.model.ImageList;
import com.google.auth.oauth2.ServiceAccountCredentials;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.util.Arrays;

public class ComputeExample {
  public static void main(String args[]) throws IOException, GeneralSecurityException {
    // Project ID for this request.
    String project = "iig-infosys"; // TODO: Update placeholder value.
    
    Compute computeService = createComputeService();
    Compute.Images.List request = computeService.images().list(project);
    Compute.Addresses.List request1 = computeService.addresses().list(project, "europe-west2");
    ImageList response;
    do {
      response = request.execute();
      if (response.getItems() == null) {
        continue;
      }
      for (Image image : response.getItems()) {
        // TODO: Change code below to process each `image` resource:
        System.out.println(image.getName());
      }
      
      request.setPageToken(response.getNextPageToken());
    } while (response.getNextPageToken() != null);
    
    
    AddressList response1;
    do {
      response1 = request1.execute();
      if (response1.getItems() == null) {
        continue;
      }
      for (Address address : response1.getItems()) {
        // TODO: Change code below to process each `address` resource:
    	  System.out.println(address.getName());
    	  if(address.getName().equalsIgnoreCase("juniper-web")) {
    		  System.out.println(address.getAddress());
    		  break;
    	  }
      }
      request1.setPageToken(response1.getNextPageToken());
    } while (response.getNextPageToken() != null);
  }

  public static Compute createComputeService() throws IOException, GeneralSecurityException {
    HttpTransport httpTransport = GoogleNetHttpTransport.newTrustedTransport();
    JsonFactory jsonFactory = JacksonFactory.getDefaultInstance();
    GoogleCredential credential = null;
    System.out.println("here");
     try (InputStream resourceAsStream = new FileInputStream("iig-infosys-c0b53aea732d.json")) {
    	 credential =GoogleCredential.fromStream(resourceAsStream);
     }
   
    if (credential.createScopedRequired()) {
      credential =
          credential.createScoped(Arrays.asList("https://www.googleapis.com/auth/cloud-platform"));
    }
    return new Compute.Builder(httpTransport, jsonFactory, credential)
        .setApplicationName("Google-ComputeSample/0.1")
        .build();
  }
}