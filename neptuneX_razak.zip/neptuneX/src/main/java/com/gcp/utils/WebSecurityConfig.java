package com.gcp.utils;

import org.springframework.core.annotation.Order;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.BeanIds;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.ldap.userdetails.UserDetailsContextMapper;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.ldap.authentication.ad.ActiveDirectoryLdapAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
 
	@Value( "${ad.domain.name}" )
	private String domain;
	
	@Value( "${ad.server.url}" )
	private String ldapurl;
	
	//@Autowired 
	//private UserDetailsContextMapper userDetailsContextMapper;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
 
		http.csrf().disable();
		http
		
		.authorizeRequests()
		.antMatchers("/","/login","/feature","/accessDenied","/error").permitAll()
		
		//.antMatchers("/home").hasAnyAuthority(AppRole.GENERIC_USER)		
        .and()
        .exceptionHandling().accessDeniedPage("/home")
        .and()
        .formLogin()
        //.loginPage("/login").defaultSuccessUrl("/login/submit")
        .permitAll();
    }
 
//    @Override
//    @Order(1)
//	protected void configure(AuthenticationManagerBuilder authManagerBuilder) throws Exception {
//		authManagerBuilder.authenticationProvider(
//				activeDirectoryLdapAuthenticationProvider());
//	}
//    
//    @Order(2)
//   	protected void configureTokenBased(AuthenticationManagerBuilder authManagerBuilder) throws Exception {
//    	authManagerBuilder.authenticationProvider(new CustomAuthenticationProvider());
//   	}
//    
//    @Bean
//	public AuthenticationProvider activeDirectoryLdapAuthenticationProvider() {
//		ActiveDirectoryLdapAuthenticationProvider provider = new ActiveDirectoryLdapAuthenticationProvider(
//				domain, ldapurl);
//		provider.setConvertSubErrorCodesToExceptions(true);
//		provider.setUseAuthenticationRequestCredentials(true);
//		provider.setUserDetailsContextMapper(userDetailsContextMapper);
//		return provider;
//	}
//    
//    @Override
//	public void configure(WebSecurity web) throws Exception {
//	    web
//	       .ignoring()
//	       .antMatchers("/resources/**", "/assets/**");
//	}
//    
//    @Bean(name = BeanIds.AUTHENTICATION_MANAGER)
//	@Override
//	public AuthenticationManager authenticationManagerBean() throws Exception {
//		return super.authenticationManagerBean();
//	}
}