package com.gcp.utils;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class OracleConnUtils {

	@Value("${oracle.jdbc.url}")
	private static String oracle_jdbc_url;
	@Value("${oracle.user.name}")
	private static String oracle_user_name;
	@Value("${oracle.encrypt.pwd}")
	private static String oracle_encrypt_pwd;
	@Value("${master.key.path}")
	private static String master_key_path;
	@Value("${spring.datasource.driver-class-name}")
	private static String driver_class_name;

	public void setJdbcUrl(String value) {
		this.oracle_jdbc_url = value;
	}
	public void setPassword(String value) {
		this.oracle_encrypt_pwd = value;
	}
	public void setMasterKeyPath(String value) {
		this.master_key_path = value;
	}

	public static Connection getOracleConnection() throws ClassNotFoundException, SQLException, Exception {
		Class.forName(driver_class_name);
		String content = EncryptionUtil.readFile(master_key_path);
		String connectionUrl = oracle_jdbc_url;
		byte[] base_pwd = org.apache.commons.codec.binary.Base64.decodeBase64(oracle_encrypt_pwd);
		String orcl_decoded_pwd = EncryptionUtil.decryptText(base_pwd, EncryptionUtil.decodeKeyFromString(content));
		Connection conn = DriverManager.getConnection(connectionUrl, oracle_user_name, orcl_decoded_pwd);
		return conn;
	}

}
