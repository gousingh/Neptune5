package com.gcp.dto;

public class AppRole {
        
	public static final String GENERIC_USER = "ROLE_GENERIC";
	public static final String Model_Admin ="Model Admin";
	public static final String Model_Build ="Model Build";
	public static final String Model_Consume ="Model Consume";
}