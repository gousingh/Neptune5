package com.gcp.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

public class UpdateUserDTO {

	private Integer oldRoleId;
	private Integer newRoleId;
	
	@NotNull
	private Integer userId;
	private String userDomain;
	private String userName;
	
	@Email
	private String email;
	
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserDomain() {
		return userDomain;
	}
	public void setUserDomain(String userDomain) {
		this.userDomain = userDomain;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getOldRoleId() {
		return oldRoleId;
	}
	public void setOldRoleId(Integer oldRoleId) {
		this.oldRoleId = oldRoleId;
	}
	public Integer getNewRoleId() {
		return newRoleId;
	}
	public void setNewRoleId(Integer newRoleId) {
		this.newRoleId = newRoleId;
	}
	@Override
	public String toString() {
		return "UpdateUserDTO [oldRoleId=" + oldRoleId + ", newRoleId=" + newRoleId + ", userId=" + userId
				+ ", userDomain=" + userDomain + ", userName=" + userName + ", email=" + email + "]";
	}
	
}
