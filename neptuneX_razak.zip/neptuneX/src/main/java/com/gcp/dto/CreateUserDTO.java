package com.gcp.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class CreateUserDTO {

	@NotNull
	private Integer roleId;
	
	@NotNull
	@NotEmpty
	private String psId;
	
	@NotNull
	@NotEmpty
	private String userDomain;
	
	@NotNull
	@NotEmpty
	private String userName;
	
	@NotNull
	@Email
	@NotEmpty
	private String email;
	
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public String getPsId() {
		return psId;
	}
	public void setPsId(String psId) {
		this.psId = psId;
	}
	public String getUserDomain() {
		return userDomain;
	}
	public void setUserDomain(String userDomain) {
		this.userDomain = userDomain;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "CreateUserDTO [roleId=" + roleId + ", psId=" + psId + ", userDomain=" + userDomain + ", userName="
				+ userName + ", email=" + email + "]";
	}
	
}
