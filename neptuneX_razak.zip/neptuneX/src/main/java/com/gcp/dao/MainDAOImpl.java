package com.gcp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.gcp.dto.UserAccount;
import com.gcp.utils.ConnectionUtils;

@Component
@Transactional
public class MainDAOImpl implements MainDAO {

	@Autowired
	private ConnectionUtils ConnectionUtils;
	
	@Value( "${mysql.connection.string}" )
	private String mysql_connection_string;
	@Value( "${mysql.username}" )
	private String mysql_username;
	@Value( "${mysql.password}" )
	private String mysql_password;

	private static String USER_MASTER_TABLE = "JUNIPER_USER_MASTER";
	Connection con;
	public ArrayList<String> getModelType() throws Exception
	{			
		ArrayList<String> modelTyp= new ArrayList<String>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
			//return true;
			Statement stmt=con.createStatement();  
			                               
			ResultSet rs=stmt.executeQuery("SELECT DISTINCT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_ID=1");
			System.out.println("SELECT DISTINCT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_ID=1");
			while(rs.next())
			{
				modelTyp.add(rs.getString(1));

			}

		}
		catch(Exception e) {
			e.printStackTrace();
			//return false;
		}

		return modelTyp;
	}
	@Override
	public ArrayList<String> getModelTypeEdit() throws Exception
	{			
		ArrayList<String> modelTyp= new ArrayList<String>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
			//return true;
			Statement stmt=con.createStatement();  
			                               
			ResultSet rs=stmt.executeQuery("SELECT DISTINCT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_TYPE_ID IN( SELECT MODEL_TYPE_ID FROM KEPLER_MODEL_MASTER WHERE KEPLER_MODEL_MASTER.MODEL_STATUS='IN-PROGRESS')");
			System.out.println("SELECT DISTINCT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_TYPE_ID IN( SELECT MODEL_TYPE_ID FROM KEPLER_MODEL_MASTER WHERE KEPLER_MODEL_MASTER.MODEL_STATUS='IN-PROGRESS' )");
			while(rs.next())
			{
				modelTyp.add(rs.getString(1));

			}

		}
		catch(Exception e) {
			e.printStackTrace();
			//return false;
		}

		return modelTyp;
	}
	
	
	@Override
	public ArrayList<String> getModelType1(String createdby) throws Exception
	{			
		ArrayList<String> modelTyp= new ArrayList<String>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
			//return true;
			Statement stmt=con.createStatement();  
			ResultSet rs=stmt.executeQuery("SELECT DISTINCT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_TYPE_ID IN( SELECT MODEL_TYPE_ID FROM KEPLER_MODEL_MASTER WHERE KEPLER_MODEL_MASTER.MODEL_STATUS='PUBLISHED_BZ')");
			System.out.println("SELECT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_TYPE_ID IN( SELECT MODEL_TYPE_ID FROM KEPLER_MODEL_MASTER WHERE KEPLER_MODEL_MASTER.MODEL_STATUS='PUBLISHED_BZ')");
			while(rs.next())
			{
				modelTyp.add(rs.getString(1));

			}
			System.out.println(modelTyp);

		}
		catch(Exception e) {
			e.printStackTrace();
			//return false;
		}

		return modelTyp;
	}
	@Override
	public ArrayList<String> getModelType2(String createdby) throws Exception
	{			
		ArrayList<String> modelTyp= new ArrayList<String>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
			//return true;
			Statement stmt=con.createStatement();  
			ResultSet rs=stmt.executeQuery("SELECT DISTINCT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_TYPE_ID IN( SELECT MODEL_TYPE_ID FROM KEPLER_MODEL_MASTER WHERE KEPLER_MODEL_MASTER.MODEL_STATUS='PUBLISHED_DS')");
			System.out.println("SELECT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_TYPE_ID IN( SELECT MODEL_TYPE_ID FROM KEPLER_MODEL_MASTER WHERE KEPLER_MODEL_MASTER.MODEL_STATUS='PUBLISHED_DS')");
			while(rs.next())
			{
				modelTyp.add(rs.getString(1));

			}
			System.out.println(modelTyp);

		}
		catch(Exception e) {
			e.printStackTrace();
			//return false;
		}

		return modelTyp;
	}
	@Override

	public ArrayList<String> getModelName1(String modelTyp,String createdby) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		System.out.println("inside getmodelnm");
		ArrayList<String> modelNm= new ArrayList<String>();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_NM FROM KEPLER_MODEL_MASTER JOIN KEPLER_REF_ENTITY ON \n" + 
				"  KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID WHERE ENTITY_VAL='"+modelTyp+"' AND MODEL_STATUS='PUBLISHED_BZ' " );
		System.out.println(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_NM FROM KEPLER_MODEL_MASTER JOIN KEPLER_REF_ENTITY ON \n" + 
				"  KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID WHERE ENTITY_VAL='"+modelTyp+"' AND MODEL_STATUS='PUBLISHED_BZ' ");
		while(rs.next()) {
			modelNm.add(rs.getString(1));
		}
		return modelNm;
	}
	@Override

	public ArrayList<String> getModelNameEdit(String modelTyp,String createdby) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		System.out.println("inside getmodelnm");
		ArrayList<String> modelNm= new ArrayList<String>();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_NM FROM KEPLER_MODEL_MASTER JOIN KEPLER_REF_ENTITY ON \n" + 
				"  KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID WHERE ENTITY_VAL='"+modelTyp+"' AND MODEL_STATUS='IN-PROGRESS' " );
		System.out.println(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_NM FROM KEPLER_MODEL_MASTER JOIN KEPLER_REF_ENTITY ON \n" + 
				"  KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID WHERE ENTITY_VAL='"+modelTyp+"' AND MODEL_STATUS='IN-PROGRESS' ");
		while(rs.next()) {
			modelNm.add(rs.getString(1));
		}
		return modelNm;
	}
	@Override

	public ArrayList<String> getModelName2(String modelTyp,String createdby) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		System.out.println("inside getmodelnm");
		ArrayList<String> modelNm= new ArrayList<String>();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_NM FROM KEPLER_MODEL_MASTER JOIN KEPLER_REF_ENTITY ON \n" + 
				"  KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID WHERE ENTITY_VAL='"+modelTyp+"' AND MODEL_STATUS='PUBLISHED_DS' " );
		System.out.println(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_NM FROM KEPLER_MODEL_MASTER JOIN KEPLER_REF_ENTITY ON \n" + 
				"  KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID WHERE ENTITY_VAL='"+modelTyp+"' AND MODEL_STATUS='PUBLISHED_DS' ");
		while(rs.next()) {
			modelNm.add(rs.getString(1));
		}
		return modelNm;
	}
	@Override
	public ArrayList<String> getModelTmpl() throws Exception {			
		ArrayList<String> modelTmpl= new ArrayList<String>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
			//return true;
			Statement stmt=con.createStatement();  
			ResultSet rs=stmt.executeQuery("SELECT DISTINCT TMPLT_NM FROM  KEPLER_TEMPLATE_MASTER");
			System.out.println("SELECT DISTINCT TMPLT_NM FROM  KEPLER_TEMPLATE_MASTER");
			while(rs.next())
			{
				modelTmpl.add(rs.getString(1));

			}

		}
		catch(Exception e) {
			e.printStackTrace();
			//return false;
		}

		return modelTmpl;
	}
	public Map<String,ArrayList<Object>> getData() throws Exception
	{			Map<String,ArrayList<Object>> Model = new HashMap<String, ArrayList<Object>>();

	try {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		//return true;
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("SELECT KEPLER_REF_ENTITY.ENTITY_VAL,KEPLER_MODEL_MASTER.MODEL_NM,KEPLER_MODEL_MASTER.MODEL_VERSN_NUM,KEPLER_MODEL_MASTER.MODEL_DESC, KEPLER_TEMPLATE_MASTER.TMPLT_NM from KEPLER_REF_ENTITY JOIN KEPLER_MODEL_MASTER ON KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID JOIN KEPLER_TEMPLATE_MASTER ON KEPLER_MODEL_MASTER.TMPLT_ID=KEPLER_TEMPLATE_MASTER.TMPLT_ID");
		ArrayList<Object> modelTyp= new ArrayList<Object>();
		ArrayList<Object> modelNm= new ArrayList<Object>();
		ArrayList<Object> modelVer= new ArrayList<Object>();
		ArrayList<Object> modelDesc= new ArrayList<Object>();
		ArrayList<Object> modelTmpl= new ArrayList<Object>();
		while(rs.next())
		{
			modelTyp.add(rs.getString(1));
			modelNm.add(rs.getString(2));
			modelVer.add(rs.getInt(3));
			modelDesc.add(rs.getString(4));
			modelTmpl.add(rs.getString(5));
		}
		Model.put("ModelType", modelTyp);
		Model.put("ModelName",modelNm);
		Model.put("ModelVersion",modelVer);
		Model.put("ModelDesc",modelDesc);
		Model.put("ModelTmpl",modelTmpl);
	}
	catch(Exception e) {
		e.printStackTrace();
		//return false;
	}

	return Model;
	}
	@Override

	public ArrayList<String> getModelName(String modelTyp) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		System.out.println("inside getmodelnm");
		ArrayList<String> modelNm= new ArrayList<String>();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_NM FROM KEPLER_MODEL_MASTER JOIN KEPLER_REF_ENTITY ON \n" + 
				"  KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID WHERE ENTITY_VAL='"+modelTyp+"' AND MODEL_STATUS='PUBLISHED_DS'" );
		System.out.println(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_NM FROM KEPLER_MODEL_MASTER JOIN KEPLER_REF_ENTITY ON \n" + 
				"  KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID WHERE ENTITY_VAL='"+modelTyp+"' AND MODEL_STATUS='PUBLISHED_DS'");
		while(rs.next()) {
			modelNm.add(rs.getString(1));
		}
		return modelNm;
	}
	@Override
	public ArrayList<String> getModelVer(String modelType,String modelName) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);

		ArrayList<String> modelVer= new ArrayList<String>();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery(" SELECT KEPLER_MODEL_MASTER.MODEL_VERSN_NUM from KEPLER_REF_ENTITY JOIN KEPLER_MODEL_MASTER \n" + 
				"  ON KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID where ENTITY_VAL= '"+modelType+"' AND \n" + 
				"  MODEL_NM='"+modelName+"' AND MODEL_STATUS='PUBLISHED_DS'");
		System.out.println(" SELECT KEPLER_MODEL_MASTER.MODEL_VERSN_NUM from KEPLER_REF_ENTITY JOIN KEPLER_MODEL_MASTER \n" + 
				"  ON KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID where ENTITY_VAL= '"+modelType+"' AND \n" + 
				"  MODEL_NM='"+modelName+"' AND MODEL_STATUS='PUBLISHED_DS'");
		while(rs.next()) {
			modelVer.add(rs.getString(1));
		}
		return modelVer;
	}
	@Override
	public ArrayList<String> getModelVer1(String modelType,String modelName,String createdby) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);

		ArrayList<String> modelVer= new ArrayList<String>();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_VERSN_NUM from KEPLER_REF_ENTITY JOIN KEPLER_MODEL_MASTER \n" + 
				"  ON KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID where ENTITY_VAL= '"+modelType+"' AND \n" + 
				"  MODEL_NM='"+modelName+"' AND MODEL_STATUS='PUBLISHED_BZ' ");
		System.out.println(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_VERSN_NUM from KEPLER_REF_ENTITY JOIN KEPLER_MODEL_MASTER \n" + 
				"  ON KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID where ENTITY_VAL= '"+modelType+"' AND \n" + 
				"  MODEL_NM='"+modelName+"' AND MODEL_STATUS='PUBLISHED_BZ' ");
		while(rs.next()) {
			modelVer.add(rs.getString(1));
		}
		return modelVer;
	}
	@Override
	public ArrayList<String> getModelVerEdit(String modelType,String modelName,String createdby) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);

		ArrayList<String> modelVer= new ArrayList<String>();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_VERSN_NUM from KEPLER_REF_ENTITY JOIN KEPLER_MODEL_MASTER \n" + 
				"  ON KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID where ENTITY_VAL= '"+modelType+"' AND \n" + 
				"  MODEL_NM='"+modelName+"' AND MODEL_STATUS='IN-PROGRESS' ");
		System.out.println(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_VERSN_NUM from KEPLER_REF_ENTITY JOIN KEPLER_MODEL_MASTER \n" + 
				"  ON KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID where ENTITY_VAL= '"+modelType+"' AND \n" + 
				"  MODEL_NM='"+modelName+"' AND MODEL_STATUS='IN-PROGRESS' ");
		while(rs.next()) {
			modelVer.add(rs.getString(1));
		}
		return modelVer;
	}
	@Override
	public int getNextModelVer(String modelType,String modelName,String createdby) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);

		int modelVer=0;
		int currVer=0;
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery(" SELECT MAX(KEPLER_MODEL_MASTER.MODEL_VERSN_NUM) from KEPLER_REF_ENTITY JOIN KEPLER_MODEL_MASTER \n" + 
				"  ON KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID where ENTITY_VAL= '"+modelType+"' AND \n" + 
				"  MODEL_NM='"+modelName+"' AND MODEL_STATUS='IN-PROGRESS' ");
		System.out.println(" SELECT MAX(KEPLER_MODEL_MASTER.MODEL_VERSN_NUM) from KEPLER_REF_ENTITY JOIN KEPLER_MODEL_MASTER \n" + 
				"  ON KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID where ENTITY_VAL= '"+modelType+"' AND \n" + 
				"  MODEL_NM='"+modelName+"' AND MODEL_STATUS='IN-PROGRESS' ");
		while(rs.next()) {
			
			modelVer=rs.getInt(1)+1;
			currVer=rs.getInt(1);
		}
		System.out.println("next ver"+modelVer);
		//insert
		PreparedStatement preparedStmt = null;
		String modelVerId="SELECT MAX(MODEL_VERSN_ID) FROM KEPLER_MODEL_MASTER";
		preparedStmt=con.prepareStatement(modelVerId);
		rs=preparedStmt.executeQuery();
		int maxId=0;
		while (rs.next()) 
			maxId=rs.getInt(1);
		maxId+=1;
		ResultSet rs1=stmt.executeQuery("SELECT * from KEPLER_REF_ENTITY JOIN KEPLER_MODEL_MASTER ON KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID where ENTITY_VAL= '"+modelType+"' AND MODEL_NM='"+modelName+"' AND MODEL_STATUS='IN-PROGRESS' AND MODEL_VERSN_NUM= "+currVer);
		System.out.println("SELECT * from KEPLER_REF_ENTITY JOIN KEPLER_MODEL_MASTER ON KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID where ENTITY_VAL= '"+modelType+"' AND MODEL_NM='"+modelName+"' AND MODEL_STATUS='IN-PROGRESS' AND MODEL_VERSN_NUM= "+currVer);
		 int rowCount=0;
		while(rs1.next()) {
			
			
		
		
		String insert="INSERT INTO KEPLER_MODEL_MASTER(TMPLT_ID,MODEL_TYPE_ID,MODEL_NM,MODEL_DESC,MODEL_LANG,MODEL_STATUS,GCP_PROJ_ID,KEPLER_PROJ_ID,CREATED_BY,CREATED_DTM,UPDATED_BY,MODEL_VERSN_NUM,MODEL_VERSN_ID,INPUT_DATASET_TYPE)" + 
				"values ("+rs1.getInt("TMPLT_ID")+","+rs1.getString("MODEL_TYPE_ID")+",'"+rs1.getString("MODEL_NM")+"','"+rs1.getString("MODEL_DESC")+"','"+rs1.getString("MODEL_LANG")+"','"+rs1.getString("MODEL_STATUS")+"',"+rs1.getString("GCP_PROJ_ID")+","+rs1.getString("KEPLER_PROJ_ID")+",'"+rs1.getString("CREATED_BY")+"','"+rs1.getString("CREATED_DTM")+"','"+rs1.getString("UPDATED_BY")+"',"+modelVer+","+maxId+",'"+rs1.getString("INPUT_DATASET_TYPE")+"')";
		System.out.println("insert new version string "+insert);
		
		preparedStmt = con.prepareStatement(insert);
		
		
		rowCount=preparedStmt.executeUpdate();
		}
		//insert
		return modelVer;
	}
	@Override
	public ArrayList<String> getModelVer2(String modelType,String modelName,String createdby) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);

		ArrayList<String> modelVer= new ArrayList<String>();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_VERSN_NUM from KEPLER_REF_ENTITY JOIN KEPLER_MODEL_MASTER \n" + 
				"  ON KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID where ENTITY_VAL= '"+modelType+"' AND \n" + 
				"  MODEL_NM='"+modelName+"' AND MODEL_STATUS='PUBLISHED_DS' ");
		System.out.println(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_VERSN_NUM from KEPLER_REF_ENTITY JOIN KEPLER_MODEL_MASTER \n" + 
				"  ON KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID where ENTITY_VAL= '"+modelType+"' AND \n" + 
				"  MODEL_NM='"+modelName+"' AND MODEL_STATUS='PUBLISHED_DS' ");
		while(rs.next()) {
			modelVer.add(rs.getString(1));
		}
		return modelVer;
	}
	/*
	 * public BigQuery returnBigqueryObject() throws Exception {
	 * 
	 * 
	 * try {
	 * 
	 * GoogleCredentials credential; File credentialsPath = new
	 * File("keplar-ec81eb8ebc8e.json"); // TODO: update to your key path.
	 * FileInputStream serviceAccountStream = new FileInputStream(credentialsPath);
	 * credential = ServiceAccountCredentials.fromStream(serviceAccountStream);
	 * BigQuery obj =
	 * BigQueryOptions.newBuilder().setCredentials(credential).build().getService();
	 * System.out.println("object ---> "+obj.toString()); return obj;
	 * }catch(Exception e) { e.printStackTrace(System.err);
	 * System.out.print("erroe"); return null; } }
	 */
	//	public ArrayList<String> getTableList( String datasetName,BigQuery bigquery) throws Exception {
	//		// TODO Auto-generated method stub
	//		try {
	//			System.out.print("tablelist"+TableListOption.pageSize(100));
	//			Page<Table> tables = bigquery.listTables(datasetName, TableListOption.pageSize(100));
	//			ArrayList<String> tableList = new ArrayList<String>();
	//			for (Table table : tables.iterateAll()) {
	//				System.out.println("Tabbles --->>"+table.getTableId().getTable());
	//				tableList.add(table.getTableId().getTable());
	//			}
	//			System.out.println("tablelist"+tableList);
	//			return tableList;
	//		}catch(Exception e) {
	//			e.printStackTrace(System.err);
	//
	//		}
	//	}
	@Override
	public ArrayList<UserAccount> getUserAccount() throws Exception {
		ArrayList<UserAccount> arrUsers= new ArrayList<UserAccount>();
		String sql = "select user_id,user_sequence from "+USER_MASTER_TABLE+"";
		Connection conn = null;
		try {
			conn= ConnectionUtils.getConnection();
			PreparedStatement pstm = conn.prepareStatement(sql); 
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				UserAccount user = new UserAccount();
				user.setUser_id(rs.getString(1));
				user.setUser_sequence(rs.getInt(2));
				arrUsers.add(user);	
			}
			pstm.close();
			rs.close();
		}catch(Exception e) {
			throw e;
		}finally {
			conn.close();
		}
		return arrUsers;
	}

	@Override
	public UserAccount findUserFromId(String user_id) throws Exception {

		String sql = "select user_id,user_pass,user_sequence from juniper_user_master where user_id='"+user_id+"'";
		Connection conn= null;
		UserAccount user = new UserAccount();
		try {
			conn= ConnectionUtils.getConnection();
			PreparedStatement pstm = conn.prepareStatement(sql); 
			ResultSet rs = pstm.executeQuery();

			while (rs.next()) {
				user.setUser_id(rs.getString(1));
				user.setUser_pass(rs.getString(2));
				user.setUser_sequence(rs.getInt(3));
			}
			pstm.close();
			rs.close();
		}
		catch(Exception e) {
			e.printStackTrace();
			throw e;
		}


		finally {
			conn.close();
		}
		return user;
	}


	@Override
	public List<String> findUserRoles(String user_id) throws Exception {

		String sql = "select distinct ugm.feature_list from juniper_user_master u,juniper_ugroup_user_link ugl,juniper_user_group_master ugm where u.user_sequence=ugl.user_sequence and ugl.USER_GROUP_SEQUENCE =ugm.USER_GROUP_SEQUENCE and u.USER_ID='"+user_id+"'";
		Connection conn= null;
		List<String> userRole = new ArrayList<String>();
		try {
			conn= ConnectionUtils.getConnection();
			PreparedStatement pstm = conn.prepareStatement(sql); 
			ResultSet rs = pstm.executeQuery();


			Set<String> features = new HashSet<String>();
			while (rs.next()) {
				for(String r: rs.getString(1).split(",")) {
					//featureId.append(r + ",");
					features.add(r);
					//userRole.add(r);	
				}
			}
			StringBuffer featureId = new StringBuffer();
			Iterator<String> it = features.iterator();
			while(it.hasNext()) {
				featureId.append(it.next()+ ",");
			}
			if(featureId.length() > 0) {
				featureId.setLength(featureId.length()-1);
				sql = "select feature_name FROM juniper_feature_master f where f.feature_sequence in (" +featureId.toString()+ ")";
				pstm = conn.prepareStatement(sql); 
				rs = pstm.executeQuery();
				while (rs.next()) {
					userRole.add(rs.getString(1));	
				}
			}
			pstm.close();
			rs.close();
		}
		catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			conn.close();
		}
		//ConnectionUtils.closeQuietly(conn);

		return userRole;
	}

	@Override
	public boolean updateModel(String ModelType, String ModelName, int ModelVersion, String time, int accuracy,
			String modelComment)  { int rowCount;boolean status;
			// TODO Auto-generated method stub
			try {
				//Timestamp tm = new Timestamp(time);
				java.sql.Timestamp ts = java.sql.Timestamp.valueOf( time ) ;
				
				Class.forName("com.mysql.jdbc.Driver");
				con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
				String query = "update KEPLER_MODEL_EXECUTION set MODEL_KPI_ACCURACY = ?,MODEL_EXC_TM = ?,MODEL_PERFOMANCE_CMNT = ?" + 
						"  WHERE MODEL_ID=" + 
						"  (select distinct a.MODEL_ID from KEPLER_MODEL_MASTER  a,KEPLER_REF_ENTITY b where a.MODEL_TYPE_ID=b.ENTITY_TYPE_ID and "
						+ "b.ENTITY_VAL=? and a.MODEL_VERSN_NUM=? and a.MODEL_NM=?)";
				PreparedStatement preparedStmt = con.prepareStatement(query);
				preparedStmt.setInt(1, accuracy);
				preparedStmt.setTimestamp(2, ts);
				preparedStmt.setString(3, modelComment);
				preparedStmt.setString(4, ModelType);
				preparedStmt.setInt(5, ModelVersion);
				preparedStmt.setString(6, ModelName);
				
				rowCount=preparedStmt.executeUpdate();
				
				con.close();
			}
			

			catch (Exception e) {
				// TODO: handle exception
				e.getStackTrace();
				return false;
			}
			if(rowCount!=0)
				return true;
			else 
				return false;
	}
	@Override
	public boolean SaveExecuteBuild(String modelType,String modelName,int modelVer, String kpi, String modelComment) {
		int rowCount;
		try {
			PreparedStatement preparedStmt = null;
			ResultSet rs =null;
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
			String modelVerId="SELECT MODEL_ID, MODEL_VERSN_ID FROM KEPLER_MODEL_MASTER WHERE MODEL_NM= '"+modelName+"' AND MODEL_VERSN_NUM="+modelVer;
			preparedStmt=con.prepareStatement(modelVerId);
			rs=preparedStmt.executeQuery();
			int modelId=0;
			int verId=0;
			while (rs.next()) 
			{
				modelId=rs.getInt(1);
				verId=rs.getInt(2);
			}
			String fetchJobId = "select MAX(job_id) FROM kepler.KEPLER_MODEL_EXECUTION";
			preparedStmt=con.prepareStatement(fetchJobId);
			rs=preparedStmt.executeQuery();
			int jobId=0;
			while (rs.next()) 
			{
				jobId=rs.getInt(1);
			}
			jobId++;
			String query = "INSERT INTO KEPLER_MODEL_EXECUTION (JOB_ID,MODEL_VERSN_ID,MODEL_ID,MODEL_KPI_ACCURACY,MODEL_PERFOMANCE_CMNT,CREATED_BY,UPDATED_BY)\r\n" + 
					"  VALUES("+jobId+","+verId+","+modelId+","+kpi+",'"+modelComment+"','admin','admin')";
			System.out.println("update query"+query); 
			preparedStmt = con.prepareStatement(query);
			rowCount=preparedStmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}


		if(rowCount!=0)
			return true;
		else 
			return false;
	}
	@Override
	public boolean SaveExecute(String modelType,String modelName,int modelVer, String remarks, String feedback) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
			
			PreparedStatement preparedStmt = null;
			
			
			ResultSet rs =null;
			
			
			Date date= new Date();
			long time = date.getTime();
			System.out.println("Time in Milliseconds: " + time);
			Timestamp ts = new Timestamp(time);
			System.out.println("Current Time Stamp: " + ts);
			
			String modelVerId="SELECT MODEL_VERSN_ID FROM KEPLER_MODEL_MASTER WHERE MODEL_NM='"+modelName+"' AND MODEL_VERSN_NUM="+modelVer;
			preparedStmt=con.prepareStatement(modelVerId);
			System.out.print("select ver"+modelVerId);
			rs=preparedStmt.executeQuery();
			int maxId=0;
			while (rs.next()) 
				maxId=rs.getInt(1);
			
			String insert="INSERT INTO KEPLER_MODEL_FEEDBACK(MODEL_CONSUMPTION_ID,RUN_ID,REMARKS,USER_ID,SHARE,RATING,CREATED_BY,CREATED_DTM,UPDATED_BY,MODEL_FEEDBACK_ID,MODEL_VRSN_ID)" + 
					"values (?,?,?,?,?,?,?,?,?,?,?)";
			preparedStmt=con.prepareStatement(insert);
//			preparedStmt.setInt(1, maxId);
			preparedStmt.setInt(1,1);
			preparedStmt.setInt(2,1);
			preparedStmt.setString(3,remarks);
			preparedStmt.setInt(4,1);
			preparedStmt.setString(5,feedback);
			preparedStmt.setInt(6,1);
			preparedStmt.setString(7,"admin");
			preparedStmt.setTimestamp(8, ts);
			preparedStmt.setString(9,"admin");
			preparedStmt.setInt(10, 1);
			preparedStmt.setInt(11, maxId);
			preparedStmt.execute();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}


		return true;
	}
	@Override
	public boolean createModel(String modelType, String modelName, String modelLibraries, String modelDesc,
			String modelTemplate) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
			String selectModelType="select KEPLER_REF_ENTITY.ENTITY_TYPE_ID FROM KEPLER_REF_ENTITY where ENTITY_VAL=?";
			PreparedStatement preparedStmt = null;
			preparedStmt=con.prepareStatement(selectModelType);
			preparedStmt.setString(1,modelType);
			ResultSet rs =null;
			rs=preparedStmt.executeQuery();
			int typeId = 0;
			while (rs.next()) 
				typeId=rs.getInt(1);
			String selectTemplateType="SELECT TMPLT_ID FROM KEPLER_TEMPLATE_MASTER WHERE TMPLT_NM= ?";
			preparedStmt=con.prepareStatement(selectTemplateType);
			preparedStmt.setString(1,modelTemplate);
			rs=preparedStmt.executeQuery();
			int templateId =0;
			Date date= new Date();
			long time = date.getTime();
			System.out.println("Time in Milliseconds: " + time);
			Timestamp ts = new Timestamp(time);
			System.out.println("Current Time Stamp: " + ts);
			while (rs.next()) 
				templateId=rs.getInt(1);
			String modelVerId="SELECT MAX(MODEL_VERSN_ID) FROM KEPLER_MODEL_MASTER";
			preparedStmt=con.prepareStatement(modelVerId);
			rs=preparedStmt.executeQuery();
			int maxId=0;
			while (rs.next()) 
				maxId=rs.getInt(1);
			maxId+=1;
			String insert="INSERT INTO KEPLER_MODEL_MASTER(TMPLT_ID,MODEL_TYPE_ID,MODEL_NM,MODEL_DESC,MODEL_LANG,MODEL_STATUS,GCP_PROJ_ID,KEPLER_PROJ_ID,CREATED_BY,CREATED_DTM,UPDATED_BY,MODEL_VERSN_NUM,MODEL_VERSN_ID,INPUT_DATASET_TYPE)" + 
					"values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			preparedStmt=con.prepareStatement(insert);
			preparedStmt.setInt(1,templateId);
			preparedStmt.setInt(2,typeId);
			preparedStmt.setString(3,modelName);
			preparedStmt.setString(4, modelDesc);
			preparedStmt.setString(5,"PYTHON" );
			preparedStmt.setString(6,"IN-PROGRESS");
			preparedStmt.setInt(7,1);
			preparedStmt.setInt(8,1);
			//	preparedStmt.setString(9, modelLibraries);
			preparedStmt.setString(9,"admin");
			preparedStmt.setTimestamp(10, ts);
			preparedStmt.setString(11, "admin");
			preparedStmt.setInt(12, 1);
			preparedStmt.setInt(13, maxId);
			preparedStmt.setString(14,"BQ");
			preparedStmt.execute();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}


		return true;
	}

	@Override
	public Map<String,Object> getmodelView(String ModelName,int ModelVersion) throws Exception
	{			Map<String,Object> map = new LinkedHashMap<String, Object>();

	try {
		
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		//return true;
		Statement stmt=con.createStatement();  
		String s="SELECT MODEL_NM,MODEL_TYPE_ID,MODEL_ID,MODEL_VERSN_ID,TMPLT_NM,PROJ_SRVC_ACCT_MAP_ID,MODEL_VERSN_NUM,MODEL_DESC,MODEL_LANG,MODEL_STATUS,GCP_PROJ_ID,PROJ_TYPE,MODEL_USER_REMARKS,INPUT_DATASET_TYPE,INPUT_LIB_LST,KEPLER_MODEL_MASTER.CREATED_BY,KEPLER_MODEL_MASTER.CREATED_DTM,KEPLER_MODEL_MASTER.UPDATED_BY,KEPLER_MODEL_MASTER.UPDATED_DTM FROM KEPLER_MODEL_MASTER  JOIN KEPLER_TEMPLATE_MASTER JOIN KEPLER_PROJECT_MASTER ON \r\n" + 
				"				 KEPLER_MODEL_MASTER.TMPLT_ID= KEPLER_TEMPLATE_MASTER.TMPLT_ID AND KEPLER_MODEL_MASTER.KEPLER_PROJ_ID= KEPLER_PROJECT_MASTER.PROJ_ID WHERE MODEL_VERSN_ID='"+ModelVersion+"' AND MODEL_NM='"+ModelName+"'";
		//String s="SELECT a.MODEL_NM,b.ENTITY_VAL,a.MODEL_STATUS,a.MODEL_DESC,a.MODEL_VERSN_NUM  FROM KEPLER_MODEL_MASTER a,KEPLER_REF_ENTITY b WHERE a.MODEL_VERSN_ID='"+ModelVersion+"' "
		//+ "AND a.MODEL_NM='"+ModelName+"' AND a.MODEL_TYPE_ID=b.ENTITY_TYPE_ID";
		ResultSet rs=stmt.executeQuery(s);

		while(rs.next())
		{
		map.put("modelName",rs.getString(1));
			map.put("modelTypId",rs.getInt(2));
			map.put("modelId",rs.getInt(3));
			map.put("modelVerId",rs.getInt(4));
			map.put("tmpltNm",rs.getString(5));
			map.put("projSrvcId",rs.getInt(6));
			map.put("modelVerNum",rs.getInt(7));
			map.put("modelDesc",rs.getString(8));
			map.put("modelLang",rs.getString(9));
			map.put("modelStatus",rs.getString(10));
			map.put("gcpProjId",rs.getInt(11));
			map.put("projTyp",rs.getString(12));
			map.put("modelUserRmks",rs.getString(13));
			map.put("inputDatasetTyp",rs.getString(14));
			map.put("inputLib",rs.getString(15));
			map.put("createdBy",rs.getString(16));
			map.put("createdTime",rs.getString(17));
			map.put("updatedBy",rs.getString(18));
			map.put("updatedTime",rs.getString(19)); 
			/*	map.put("modelName",rs.getString(1));
			map.put("modelTypId",rs.getString(2));
			map.put("modelStatus",rs.getString(3));
			map.put("modelDesc",rs.getString(4));
			map.put("modelVerNum",rs.getInt(5)); */


		}
		

	}
	catch(Exception e) {
		e.printStackTrace();
		//return false;
	}

	return map;
	}

	
	@Override
	public Map<String,ArrayList<Object>> getViewTable(String ModelType,String ModelName) throws Exception
	{			//Map<String,Map<String,Object>> map = new LinkedHashMap<String, Map<String,Object>>();
		Map<String,ArrayList<Object>> map= new HashMap<String, ArrayList<Object>>();
		

	try {
		
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		//return true;
		Statement stmt=con.createStatement();  
		ArrayList<Object> modelVer= new ArrayList<Object>();
		ArrayList<Object> modelNm= new ArrayList<Object>();
		ArrayList<Object> modelDesc= new ArrayList<Object>();
		ArrayList<Object> modelStatus= new ArrayList<Object>();
		ArrayList<Object> updatedDate= new ArrayList<Object>();
		String s="SELECT a.MODEL_VERSN_NUM,a.MODEL_NM,a.MODEL_DESC,a.MODEL_STATUS,a.UPDATED_DTM  FROM KEPLER_MODEL_MASTER a,KEPLER_REF_ENTITY b WHERE b.ENTITY_VAL='"+ModelType+"' "
					+ " AND a.MODEL_NM='"+ModelName+"' AND a.MODEL_TYPE_ID=b.ENTITY_TYPE_ID";
		ResultSet rs=stmt.executeQuery(s);
		while(rs.next())
		{
			modelVer.add(rs.getInt(1));
			modelNm.add(rs.getString(2));
			modelDesc.add(rs.getString(3));
			modelStatus.add(rs.getString(4));
			updatedDate.add(rs.getString(5));
		
		}
		
		map.put("modelVer", modelVer);
		map.put("modelNm", modelNm);
		map.put("modelDesc", modelDesc);
		map.put("modelStatus", modelStatus);
		map.put("updatedDate", updatedDate);
		
	}
	catch(Exception e) {
		e.printStackTrace();
		//return false;
	}
	return map;
	}

	@Override
	public boolean publishModel(String modelType, String modelName, int modelVer,String check) {
		// TODO Auto-generated method stub
		int rowCount = 0;
		try {
			
			System.out.println("check"+check);
			if(check.equalsIgnoreCase("DS")) {
				
				rowCount=updateModel(modelName,modelVer,"AWT_APRVL_PUBLISH_DS");	
			}
			
			else if(check.equalsIgnoreCase("BU"))
			rowCount=insertModel(modelName,modelVer,"AWT_APRVL_PUBLISH_BZ");
			else if(check.equalsIgnoreCase("BOTH"))
			{
				rowCount=updateModel(modelName,modelVer,"AWT_APRVL_PUBLISH_DS");
				rowCount=insertModel(modelName,modelVer,"AWT_APRVL_PUBLISH_BZ");
			}
		
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		if(rowCount!=0)
			return true;
		else 
			return false;
	}
int updateModel(String modelName,int modelVer,String status) {
	int cnt=0;
	PreparedStatement preparedStmt = null;
	
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		
		String query = "UPDATE KEPLER_MODEL_MASTER SET MODEL_STATUS='"+status+"' WHERE MODEL_NM='"+modelName+"' AND MODEL_VERSN_NUM= "+modelVer;
		System.out.println("update query"+query); 
		preparedStmt = con.prepareStatement(query);
		cnt=preparedStmt.executeUpdate();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return cnt;
}
int insertModel(String modelName,int modelVer,String status) {
	int cnt=0;
PreparedStatement preparedStmt = null;
	
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		
		String query = "INSERT INTO KEPLER_MODEL_MASTER  \r\n" + 
				" ( TMPLT_ID, PROJ_SRVC_ACCT_MAP_ID,MODEL_TYPE_ID,MODEL_ID,MODEL_VERSN_NUM,MODEL_NM,MODEL_DESC,MODEL_LANG,MODEL_STATUS,\r\n" + 
				"  GCP_PROJ_ID,KEPLER_PROJ_ID,MODEL_USER_REMARKS,INPUT_DATASET_TYPE,INPUT_LIB_LST,CREATED_BY,CREATED_DTM,UPDATED_BY,UPDATED_DTM)\r\n" + 
				" select  TMPLT_ID, PROJ_SRVC_ACCT_MAP_ID,MODEL_TYPE_ID,MODEL_ID,MODEL_VERSN_NUM,MODEL_NM,MODEL_DESC,MODEL_LANG,'"+status+"'," + 
				" GCP_PROJ_ID,KEPLER_PROJ_ID,MODEL_USER_REMARKS,INPUT_DATASET_TYPE,INPUT_LIB_LST,CREATED_BY,CREATED_DTM,UPDATED_BY,UPDATED_DTM\r\n" + 
				" from KEPLER_MODEL_MASTER\r\n" + 
				" where MODEL_NM='"+modelName+"' AND MODEL_VERSN_NUM= "+modelVer;
		System.out.println("INSERT query"+query); 
		preparedStmt = con.prepareStatement(query);
		cnt=preparedStmt.executeUpdate();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return cnt;
}

@Override
public ArrayList<String> getGoogleApi() throws Exception {
	// TODO Auto-generated method stub
	ArrayList<String> googleApi= new ArrayList<String>();
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		//return true;
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("SELECT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_ID=4");
		//System.out.println("SELECT DISTINCT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_ID=1");
		while(rs.next())
		{
			googleApi.add(rs.getString(1));

		}
	}
	catch (Exception e) {
		// TODO: handle exception
	}
	return googleApi;
	
}
@Override
public ArrayList<String> getModelLibraries() throws Exception {
	// TODO Auto-generated method stub
	ArrayList<String> modelLib= new ArrayList<String>();
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		//return true;
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("SELECT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_ID=5");
		//System.out.println("SELECT DISTINCT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_ID=1");
		while(rs.next())
		{
			modelLib.add(rs.getString(1));

		}
		
	}
	catch (Exception e) {
		// TODO: handle exception
	}
	return modelLib;
}
@Override
public ArrayList<String> getModelTypeBZ() throws Exception {
	// TODO Auto-generated method stub
	ArrayList<String> modelTyp= new ArrayList<String>();
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		//return true;
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("SELECT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_TYPE_ID IN( SELECT MODEL_TYPE_ID FROM KEPLER_MODEL_MASTER WHERE MODEL_STATUS='PUBLISHED_BZ')");
		//System.out.println("SELECT DISTINCT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_ID=1");
		while(rs.next())
		{
			modelTyp.add(rs.getString(1));

		}

	}
	catch(Exception e) {
		e.printStackTrace();
		//return false;
	}

	return modelTyp;
}
@Override
public ArrayList<String> getModelTypeDS() throws Exception {
	// TODO Auto-generated method stub
	ArrayList<String> modelTyp= new ArrayList<String>();
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		//return true;
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("SELECT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_TYPE_ID IN( SELECT MODEL_TYPE_ID FROM KEPLER_MODEL_MASTER WHERE MODEL_STATUS='PUBLISHED_DS')");
		//System.out.println("SELECT DISTINCT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_ID=1");
		while(rs.next())
		{
			modelTyp.add(rs.getString(1));

		}

	}
	catch(Exception e) {
		e.printStackTrace();
		//return false;
	}

	return modelTyp;
}
@Override
public ArrayList<String> getModelNameBZ(String modelType) throws Exception {
	// TODO Auto-generated method stub
	Class.forName("com.mysql.jdbc.Driver");
	con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
	//System.out.println("inside getmodelnm");
	ArrayList<String> modelNm= new ArrayList<String>();
	Statement stmt=con.createStatement();  
	ResultSet rs=stmt.executeQuery(" SELECT MODEL_NM FROM KEPLER_MODEL_MASTER WHERE MODEL_STATUS='PUBLISHED_BZ' AND MODEL_TYPE_ID IN (SELECT KEPLER_REF_ENTITY.ENTITY_TYPE_ID FROM KEPLER_REF_ENTITY WHERE ENTITY_VAL='"+modelType+"')");
//	System.out.println(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_NM FROM KEPLER_MODEL_MASTER JOIN KEPLER_REF_ENTITY ON \n" + 
	//		"  KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID WHERE ENTITY_VAL='"+modelTyp+"' MODEL_STATUS='PUBLISHED'");
	while(rs.next()) {
		modelNm.add(rs.getString(1));
	}
	return modelNm;
}
@Override
public ArrayList<String> getModelNameDS(String modelType) throws Exception {
	// TODO Auto-generated method stub
	Class.forName("com.mysql.jdbc.Driver");
	con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
	//System.out.println("inside getmodelnm");
	ArrayList<String> modelNm= new ArrayList<String>();
	Statement stmt=con.createStatement();  
	ResultSet rs=stmt.executeQuery("SELECT MODEL_NM FROM KEPLER_MODEL_MASTER WHERE MODEL_STATUS='PUBLISHED_DS' AND MODEL_TYPE_ID IN(SELECT KEPLER_REF_ENTITY.ENTITY_TYPE_ID FROM KEPLER_REF_ENTITY WHERE ENTITY_VAL='"+modelType+"')");
//	System.out.println(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_NM FROM KEPLER_MODEL_MASTER JOIN KEPLER_REF_ENTITY ON \n" + 
	//		"  KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID WHERE ENTITY_VAL='"+modelTyp+"' MODEL_STATUS='PUBLISHED'");
	while(rs.next()) {
		modelNm.add(rs.getString(1));
	}
	return modelNm;
}

@Override
public Map<String,Object> getModelEdit(String modelType,String modelName,String modelVersion) throws Exception
{			//Map<String,Map<String,Object>> map = new LinkedHashMap<String, Map<String,Object>>();
	Map<String,Object> map= new HashMap<String, Object>();
	

try {
	
	Class.forName("com.mysql.jdbc.Driver");
	con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
	//return true;
	Statement stmt=con.createStatement();  
	
	String s="SELECT a.MODEL_EXC_TM,a.MODEL_KPI_ACCURACY,a.MODEL_PERFOMANCE_CMNT FROM KEPLER_MODEL_EXECUTION a, KEPLER_MODEL_MASTER b,KEPLER_REF_ENTITY c WHERE a.MODEL_VERSN_ID=b.MODEL_VERSN_ID \n" 
				+ "AND c.ENTITY_VAL='"+modelType+"' \n"  
				+ " AND b.MODEL_NM='"+modelName+"' AND b.MODEL_VERSN_NUM='"+modelVersion+"' AND b.MODEL_TYPE_ID=c.ENTITY_TYPE_ID";
	System.out.println("SELECT a.MODEL_EXC_TM,a.MODEL_KPI_ACCURACY,a.MODEL_PERFOMANCE_CMNT FROM KEPLER_MODEL_EXECUTION a, KEPLER_MODEL_MASTER b,KEPLER_REF_ENTITY c WHERE a.MODEL_VERSN_ID=b.MODEL_VERSN_ID \n" 
				+ "AND c.ENTITY_VAL='"+modelType+"' \n"  
				+ " AND b.MODEL_NM='"+modelName+"' AND b.MODEL_VERSN_NUM='"+modelVersion+"' AND b.MODEL_TYPE_ID=c.ENTITY_TYPE_ID");
	ResultSet rs=stmt.executeQuery(s);
	while(rs.next())
	{
		map.put("modelExecTm",rs.getString(1));
		map.put("modelAccuracy",rs.getInt(2));
		map.put("modelPerfCmmnt",rs.getString(3));
	
	}

	
}
catch(Exception e) {
	e.printStackTrace();
	//return false;
}
return map;
}

@Override
public Map<String,ArrayList<Object>> getGraphValues(String modelType,String modelName,String kpi) throws Exception
{			//Map<String,Map<String,Object>> map = new LinkedHashMap<String, Map<String,Object>>();
	Map<String,ArrayList<Object>> map= new HashMap<String, ArrayList<Object>>();
	

try {
	
	Class.forName("com.mysql.jdbc.Driver");
	con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
	//return true;
	Statement stmt=con.createStatement();  
	ArrayList<Object> modelVer= new ArrayList<Object>();
	ArrayList<Object> kpiAccuracy= new ArrayList<Object>();
	String s=null;
	
	if(kpi.equals("ACCURACY")) {
		System.out.println("inside accuracy");
	  s="SELECT DISTINCT a.MODEL_VERSN_NUM,b.MODEL_KPI_ACCURACY  FROM KEPLER_MODEL_MASTER a,KEPLER_MODEL_EXECUTION b,KEPLER_REF_ENTITY c WHERE c.ENTITY_VAL='"+modelType+"' "
				+ " AND a.MODEL_NM='"+modelName+"' AND a.MODEL_TYPE_ID=c.ENTITY_TYPE_ID AND a.MODEL_VERSN_ID=b.MODEL_VERSN_ID";
	 
	}
	if(kpi.equals("ENTROPY_LOSS"))
	 s="SELECT DISTINCT a.MODEL_VERSN_NUM,b.MODEL_KPI_CROSS_ENTROPYLOSS  FROM KEPLER_MODEL_MASTER a,KEPLER_MODEL_EXECUTION b,KEPLER_REF_ENTITY c WHERE c.ENTITY_VAL='"+modelType+"' "
			+ " AND a.MODEL_NM='"+modelName+"' AND a.MODEL_TYPE_ID=c.ENTITY_TYPE_ID AND a.MODEL_VERSN_ID=b.MODEL_VERSN_ID";
	if(kpi.equals("LOG_LOSS"))
	 s="SELECT DISTINCT a.MODEL_VERSN_NUM,b.MODEL_KPI_LOGLOSS  FROM KEPLER_MODEL_MASTER a,KEPLER_MODEL_EXECUTION b,KEPLER_REF_ENTITY c WHERE c.ENTITY_VAL='"+modelType+"' "
			+ " AND a.MODEL_NM='"+modelName+"' AND a.MODEL_TYPE_ID=c.ENTITY_TYPE_ID AND a.MODEL_VERSN_ID=b.MODEL_VERSN_ID";
	if(kpi.equals("USER_DEF1"))
	 s="SELECT DISTINCT a.MODEL_VERSN_NUM,b.MODEL_KPI_USERDEF1  FROM KEPLER_MODEL_MASTER a,KEPLER_MODEL_EXECUTION b,KEPLER_REF_ENTITY c WHERE c.ENTITY_VAL='"+modelType+"' "
			+ " AND a.MODEL_NM='"+modelName+"' AND a.MODEL_TYPE_ID=c.ENTITY_TYPE_ID AND a.MODEL_VERSN_ID=b.MODEL_VERSN_ID";
	if(kpi.equals("USER_DEF2"))
	 s="SELECT DISTINCT a.MODEL_VERSN_NUM,b.MODEL_KPI_USERDEF2  FROM KEPLER_MODEL_MASTER a,KEPLER_MODEL_EXECUTION b,KEPLER_REF_ENTITY c WHERE c.ENTITY_VAL='"+modelType+"' "
			+ " AND a.MODEL_NM='"+modelName+"' AND a.MODEL_TYPE_ID=c.ENTITY_TYPE_ID AND a.MODEL_VERSN_ID=b.MODEL_VERSN_ID";
	System.out.println(s);
	ResultSet rs=stmt.executeQuery(s);
	while(rs.next())
	{
		modelVer.add(rs.getInt(1));
		kpiAccuracy.add(rs.getInt(2));
		
	
	}
	
	map.put("modelVer", modelVer);
	map.put("kpiAccuracy", kpiAccuracy);

}
catch(Exception e) {
	e.printStackTrace();
	//return false;
}
return map;
}


@Override
public boolean storeFeedback(String modelType,String modelName,String feedback,int rating) throws Exception
{			
	
try {
	
	Class.forName("com.mysql.jdbc.Driver");
	con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
	//return true;
	PreparedStatement preparedStmt = null;
	Statement stmt=con.createStatement(); 
	
	ResultSet rs =null;
	
	
	Date date= new Date();
	long time = date.getTime();
	System.out.println("Time in Milliseconds: " + time);
	Timestamp ts = new Timestamp(time);
	System.out.println("Current Time Stamp: " + ts);
	
	String modelVerId="SELECT a.MODEL_VERSN_ID  FROM KEPLER_MODEL_MASTER a ,KEPLER_REF_ENTITY b WHERE b.ENTITY_VAL='"+modelType+"' " 
							+ " AND a.MODEL_NM='"+modelName+"' AND a.MODEL_TYPE_ID=b.ENTITY_TYPE_ID";
	
	System.out.print("select ver"+modelVerId);
	rs=stmt.executeQuery(modelVerId);
	int maxId=0;
	while (rs.next()) 
		maxId=rs.getInt(1);
	System.out.println(maxId);
	String feedbackId="SELECT MAX(MODEL_FEEDBACK_ID) FROM KEPLER_MODEL_FEEDBACK";
	preparedStmt=con.prepareStatement(feedbackId);
	rs=preparedStmt.executeQuery();
	int maxfeedbackId=0;
	while (rs.next()) 
		maxfeedbackId=rs.getInt(1);
	maxfeedbackId+=1;
	
	
	String insert="INSERT INTO KEPLER_MODEL_FEEDBACK(MODEL_VRSN_ID,RUN_ID,USER_ID,SHARE,RATING,CREATED_BY,CREATED_DTM,UPDATED_BY,UPDATED_DTM,MODEL_FEEDBACK_ID,REMARKS) " + 
			"					 VALUES (?,?,?,?,?,?,?,?,?,?,?)";
	preparedStmt=con.prepareStatement(insert);
	preparedStmt.setInt(1,maxId);
	preparedStmt.setInt(2,1);
	preparedStmt.setInt(3,1);
	preparedStmt.setString(4,"Y");
	preparedStmt.setInt(5,rating);
	preparedStmt.setString(6,"admin");
	preparedStmt.setTimestamp(7,ts);
	preparedStmt.setString(8, "admin");
	preparedStmt.setTimestamp(9,ts);
	preparedStmt.setInt(10,maxfeedbackId);
	preparedStmt.setString(11,feedback);
	preparedStmt.execute();
} catch (Exception e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	return false;
}


return true;
}

@Override
public ArrayList<String> getKpiValues() throws Exception
{			
	ArrayList<String> kpi= new ArrayList<String>();
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		//return true;
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("SELECT DISTINCT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_ID=6");
		while(rs.next())
		{
			kpi.add(rs.getString(1));

		}
		System.out.println("in dao "+kpi);

	}
	catch(Exception e) {
		e.printStackTrace();
		//return false;
	}

	return kpi;
}

@Override
public ArrayList<String> getModelTypeView(String createdby) throws Exception
{			
	ArrayList<String> modelTyp= new ArrayList<String>();
	try {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		//return true;
		Statement stmt=con.createStatement();  
		                               
		ResultSet rs=stmt.executeQuery("SELECT DISTINCT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_TYPE_ID IN( SELECT MODEL_TYPE_ID FROM KEPLER_MODEL_MASTER)");
		System.out.println("SELECT DISTINCT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE ENTITY_TYPE_ID IN( SELECT MODEL_TYPE_ID FROM KEPLER_MODEL_MASTER )");
		while(rs.next())
		{
			modelTyp.add(rs.getString(1));

		}

	}
	catch(Exception e) {
		e.printStackTrace();
		//return false;
	}

	return modelTyp;
}

@Override

public ArrayList<String> getModelNameView(String modelType,String createdby) throws Exception {
	// TODO Auto-generated method stub
	Class.forName("com.mysql.jdbc.Driver");
	con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
	System.out.println("inside getmodelnm");
	ArrayList<String> modelNm= new ArrayList<String>();
	Statement stmt=con.createStatement();  
	ResultSet rs=stmt.executeQuery(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_NM FROM KEPLER_MODEL_MASTER JOIN KEPLER_REF_ENTITY ON \n" + 
			"  KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID WHERE ENTITY_VAL='"+modelType+"'  " );
	System.out.println(" SELECT DISTINCT KEPLER_MODEL_MASTER.MODEL_NM FROM KEPLER_MODEL_MASTER JOIN KEPLER_REF_ENTITY ON \n" + 
			"  KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID WHERE ENTITY_VAL='"+modelType+"'  ");
	while(rs.next()) {
		modelNm.add(rs.getString(1));
	}
	return modelNm;
}
}
