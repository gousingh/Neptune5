package com.gcp.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gcp.dto.CreateUserDTO;
import com.gcp.dto.UpdateUserDTO;
import com.gcp.dto.UserAccount;
import com.gcp.pojo.adminpanel.Role;
import com.gcp.pojo.adminpanel.UserDataTable;

public interface AdminDAO {
	ArrayList<UserAccount> getUserAccount() throws Exception;
	UserAccount findUserFromId(String user_id) throws Exception;
	List<String> findUserRoles(String user_id) throws Exception;
	ArrayList<String> getModelType() throws Exception;
	ArrayList<String> getModelName(String modelType) throws Exception;
	ArrayList<String> getModelVer(String modelType,String modelName) throws Exception;
	 Map<String,ArrayList<Object>> getData() throws Exception;
	 boolean updateModel(String modelType,String modelName,int modelVersion,long time,int accuracy,String modelComment) throws Exception;
	 boolean createModel(String modelType,String modelName,String modelLibraries,String modelDesc,String modelTemplate) throws Exception;
//	 ArrayList<String> getTableList( String datasetName,BigQuery bigquery) throws Exception ;
//	 public BigQuery returnBigqueryObject() throws Exception;
	 Map<String,Object> getmodelView(String ModelName,int ModelVersion) throws Exception;
	 boolean SaveExecute(String modelType,String modelName,int modelVer, String remarks, String feedback);
	 boolean SaveExecuteBuild(String modelType, String modelName, int modelVer, String kpi, String modelComment);
	//boolean updateModeldspublish(String ModelType, String ModelName, int ModelVersion);
	List<Role> listRoles() throws Exception;
	List<UserDataTable> listUsers() throws Exception;
	boolean createuser(CreateUserDTO createUserDto) throws Exception;
	boolean createRole(String roleName,String schema[]);
	HashMap<Integer,String> getRoleNames()throws Exception;
	public List<String> getFeatures(int roleId) throws Exception;
	boolean modifyRole(String roleName,String schema[]);
	boolean updateUser(UpdateUserDTO updateUserDto) throws Exception;
	boolean publishModel(String modelType, String modelName, int modelVer, String check);
	
	boolean createProject(String projectNm, String projectDesc, String projOwner, String projId1, String projNm,
			String g_projOwner)throws Exception;
	HashMap<Integer,String> getProjectNames()throws Exception;
	
	HashMap<String,String> getProjectdetails(int projId)throws Exception;
	
	boolean checkProjectName(String projectNm)throws Exception;
	boolean updateProject(int KprojectId,String projectNm, String projectDesc, String projOwner, String projId1, String projNm,
			String g_projOwner)throws Exception;
}
