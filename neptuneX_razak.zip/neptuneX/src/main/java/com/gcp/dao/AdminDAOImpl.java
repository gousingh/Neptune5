package com.gcp.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.gcp.dto.CreateUserDTO;
import com.gcp.dto.UpdateUserDTO;
import com.gcp.dto.UserAccount;
import com.gcp.pojo.adminpanel.Role;
import com.gcp.pojo.adminpanel.UserDataTable;
import com.gcp.utils.ConnectionUtils;

@Component
@Transactional
public class AdminDAOImpl implements AdminDAO {

	@Autowired
	private ConnectionUtils ConnectionUtils;
	
	@Value( "${mysql.connection.string}" )
	private String mysql_connection_string;
	@Value( "${mysql.username}" )
	private String mysql_username;
	@Value( "${mysql.password}" )
	private String mysql_password;

	private static String USER_MASTER_TABLE = "JUNIPER_USER_MASTER";
	Connection con;
	public ArrayList<String> getModelType() throws Exception
	{			
		ArrayList<String> modelTyp= new ArrayList<String>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
			//return true;
			Statement stmt=con.createStatement();  
			ResultSet rs=stmt.executeQuery(" SELECT DISTINCT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE  ENTITY_ID =1 AND ENTITY_TYPE_ID IN "
					+ "(SELECT DISTINCT MODEL_TYPE_ID FROM KEPLER_MODEL_MASTER WHERE MODEL_STATUS IN "
					+ "('AWT_APRVL_PUBLISH_DS','AWT_APRVL_PUBLISH_BZ'))");
			System.out.println("SELECT DISTINCT ENTITY_VAL FROM KEPLER_REF_ENTITY WHERE  ENTITY_ID =1 AND ENTITY_TYPE_ID IN "
					+ "(SELECT DISTINCT MODEL_TYPE_ID FROM KEPLER_MODEL_MASTER WHERE MODEL_STATUS IN "
					+ "('AWT_APRVL_PUBLISH_DS','AWT_APRVL_PUBLISH_BZ'))");
			while(rs.next())
			{
				modelTyp.add(rs.getString(1));

			}

		}
		catch(Exception e) {
			e.printStackTrace();
			//return false;
		}

		return modelTyp;
	}

	public Map<String,ArrayList<Object>> getData() throws Exception
	{			Map<String,ArrayList<Object>> Model = new HashMap<String, ArrayList<Object>>();

	try {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		//return true;
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("SELECT KEPLER_REF_ENTITY.ENTITY_VAL,KEPLER_MODEL_MASTER.MODEL_NM,KEPLER_MODEL_MASTER.MODEL_VERSN_NUM,KEPLER_MODEL_MASTER.MODEL_DESC, KEPLER_TEMPLATE_MASTER.TMPLT_NM from KEPLER_REF_ENTITY JOIN KEPLER_MODEL_MASTER ON KEPLER_REF_ENTITY.ENTITY_TYPE_ID=KEPLER_MODEL_MASTER.MODEL_TYPE_ID JOIN KEPLER_TEMPLATE_MASTER ON KEPLER_MODEL_MASTER.TMPLT_ID=KEPLER_TEMPLATE_MASTER.TMPLT_ID");
		ArrayList<Object> modelTyp= new ArrayList<Object>();
		ArrayList<Object> modelNm= new ArrayList<Object>();
		ArrayList<Object> modelVer= new ArrayList<Object>();
		ArrayList<Object> modelDesc= new ArrayList<Object>();
		ArrayList<Object> modelTmpl= new ArrayList<Object>();
		while(rs.next())
		{
			modelTyp.add(rs.getString(1));
			modelNm.add(rs.getString(2));
			modelVer.add(rs.getInt(3));
			modelDesc.add(rs.getString(4));
			modelTmpl.add(rs.getString(5));
		}
		Model.put("ModelType", modelTyp);
		Model.put("ModelName",modelNm);
		Model.put("ModelVersion",modelVer);
		Model.put("ModelDesc",modelDesc);
		Model.put("ModelTmpl",modelTmpl);
	}
	catch(Exception e) {
		e.printStackTrace();
		//return false;
	}

	return Model;
	}
	@Override

	public ArrayList<String> getModelName(String modelTyp) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		System.out.println("inside getmodelnm");
		ArrayList<String> modelNm= new ArrayList<String>();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery(" SELECT DISTINCT MODEL_NM FROM KEPLER_MODEL_MASTER WHERE MODEL_TYPE_ID IN "
				+ "(SELECT DISTINCT ENTITY_TYPE_ID FROM KEPLER_REF_ENTITY WHERE ENTITY_ID =1 AND ENTITY_VAL='"+modelTyp+"') "
						+ "AND MODEL_STATUS IN ('AWT_APRVL_PUBLISH_DS','AWT_APRVL_PUBLISH_BZ')" );
		
		System.out.println(" SELECT DISTINCT MODEL_NM FROM KEPLER_MODEL_MASTER WHERE MODEL_TYPE_ID IN (SELECT DISTINCT ENTITY_TYPE_ID FROM KEPLER_REF_ENTITY WHERE ENTITY_ID =1 AND ENTITY_VAL='"+modelTyp+"')  AND MODEL_STATUS IN ('AWT_APRVL_PUBLISH_DS','AWT_APRVL_PUBLISH_BZ')" );
		while(rs.next()) {
			modelNm.add(rs.getString(1));
		}
		return modelNm;
	}
	
	@Override
	public ArrayList<String> getModelVer(String modelType,String modelName) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);

		ArrayList<String> modelVer= new ArrayList<String>();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("SELECT DISTINCT MODEL_VERSN_NUM FROM KEPLER_MODEL_MASTER WHERE MODEL_NM='"+modelName+"' "
				+ "AND MODEL_TYPE_ID IN (SELECT ENTITY_TYPE_ID FROM KEPLER_REF_ENTITY WHERE ENTITY_ID =1 "
				+ "AND ENTITY_VAL = '"+modelType+"') AND MODEL_STATUS IN ('AWT_APRVL_PUBLISH_DS','AWT_APRVL_PUBLISH_BZ')");
		
		System.out.println("SELECT DISTINCT MODEL_VERSN_NUM FROM KEPLER_MODEL_MASTER WHERE MODEL_NM='"+modelName+"' "
				+ "AND MODEL_TYPE_ID IN (SELECT ENTITY_TYPE_ID FROM KEPLER_REF_ENTITY WHERE ENTITY_ID =1 "
				+ "AND ENTITY_VAL = '"+modelType+"') AND MODEL_STATUS IN ('AWT_APRVL_PUBLISH_DS','AWT_APRVL_PUBLISH_BZ')");
		while(rs.next()) {
			modelVer.add(rs.getString(1));
		}
		return modelVer;
	}

	/*
	 * public BigQuery returnBigqueryObject() throws Exception {
	 * 
	 * 
	 * try {
	 * 
	 * GoogleCredentials credential; File credentialsPath = new
	 * File("keplar-ec81eb8ebc8e.json"); // TODO: update to your key path.
	 * FileInputStream serviceAccountStream = new FileInputStream(credentialsPath);
	 * credential = ServiceAccountCredentials.fromStream(serviceAccountStream);
	 * BigQuery obj =
	 * BigQueryOptions.newBuilder().setCredentials(credential).build().getService();
	 * System.out.println("object ---> "+obj.toString()); return obj;
	 * }catch(Exception e) { e.printStackTrace(System.err);
	 * System.out.print("erroe"); return null; } }
	 */
	//	public ArrayList<String> getTableList( String datasetName,BigQuery bigquery) throws Exception {
	//		// TODO Auto-generated method stub
	//		try {
	//			System.out.print("tablelist"+TableListOption.pageSize(100));
	//			Page<Table> tables = bigquery.listTables(datasetName, TableListOption.pageSize(100));
	//			ArrayList<String> tableList = new ArrayList<String>();
	//			for (Table table : tables.iterateAll()) {
	//				System.out.println("Tabbles --->>"+table.getTableId().getTable());
	//				tableList.add(table.getTableId().getTable());
	//			}
	//			System.out.println("tablelist"+tableList);
	//			return tableList;
	//		}catch(Exception e) {
	//			e.printStackTrace(System.err);
	//
	//		}
	//	}
	@Override
	public ArrayList<UserAccount> getUserAccount() throws Exception {
		ArrayList<UserAccount> arrUsers= new ArrayList<UserAccount>();
		String sql = "select user_id,user_sequence from "+USER_MASTER_TABLE+"";
		Connection conn = null;
		try {
			conn= ConnectionUtils.getConnection();
			PreparedStatement pstm = conn.prepareStatement(sql); 
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				UserAccount user = new UserAccount();
				user.setUser_id(rs.getString(1));
				user.setUser_sequence(rs.getInt(2));
				arrUsers.add(user);	
			}
			pstm.close();
			rs.close();
		}catch(Exception e) {
			throw e;
		}finally {
			conn.close();
		}
		return arrUsers;
	}

	@Override
	public UserAccount findUserFromId(String user_id) throws Exception {

		String sql = "select user_id,user_pass,user_sequence from juniper_user_master where user_id='"+user_id+"'";
		Connection conn= null;
		UserAccount user = new UserAccount();
		try {
			conn= ConnectionUtils.getConnection();
			PreparedStatement pstm = conn.prepareStatement(sql); 
			ResultSet rs = pstm.executeQuery();

			while (rs.next()) {
				user.setUser_id(rs.getString(1));
				user.setUser_pass(rs.getString(2));
				user.setUser_sequence(rs.getInt(3));
			}
			pstm.close();
			rs.close();
		}
		catch(Exception e) {
			e.printStackTrace();
			throw e;
		}


		finally {
			conn.close();
		}
		return user;
	}


	@Override
	public List<String> findUserRoles(String user_id) throws Exception {

		String sql = "select distinct ugm.feature_list from juniper_user_master u,juniper_ugroup_user_link ugl,juniper_user_group_master ugm where u.user_sequence=ugl.user_sequence and ugl.USER_GROUP_SEQUENCE =ugm.USER_GROUP_SEQUENCE and u.USER_ID='"+user_id+"'";
		Connection conn= null;
		List<String> userRole = new ArrayList<String>();
		try {
			conn= ConnectionUtils.getConnection();
			PreparedStatement pstm = conn.prepareStatement(sql); 
			ResultSet rs = pstm.executeQuery();


			Set<String> features = new HashSet<String>();
			while (rs.next()) {
				for(String r: rs.getString(1).split(",")) {
					//featureId.append(r + ",");
					features.add(r);
					//userRole.add(r);	
				}
			}
			StringBuffer featureId = new StringBuffer();
			Iterator<String> it = features.iterator();
			while(it.hasNext()) {
				featureId.append(it.next()+ ",");
			}
			if(featureId.length() > 0) {
				featureId.setLength(featureId.length()-1);
				sql = "select feature_name FROM juniper_feature_master f where f.feature_sequence in (" +featureId.toString()+ ")";
				pstm = conn.prepareStatement(sql); 
				rs = pstm.executeQuery();
				while (rs.next()) {
					userRole.add(rs.getString(1));	
				}
			}
			pstm.close();
			rs.close();
		}
		catch(Exception e) {
			e.printStackTrace();
			throw e;
		}
		finally {
			conn.close();
		}
		//ConnectionUtils.closeQuietly(conn);

		return userRole;
	}

	@Override
	public boolean updateModel(String ModelType, String ModelName, int ModelVersion, long time, int accuracy,
			String modelComment)  { int rowCount;boolean status;
			// TODO Auto-generated method stub
			try {
				Timestamp tm = new Timestamp(time);
				Class.forName("com.mysql.jdbc.Driver");
				con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
				String query = "update KEPLER_MODEL_EXECUTION set MODEL_KPI_ACCURACY = ?,MODEL_EXC_TM = ?,MODEL_PERFOMANCE_CMNT = ?" + 
						"  WHERE MODEL_ID=" + 
						"  (select MODEL_ID from KEPLER_MODEL_MASTER WHERE MODEL_NM=? and MODEL_VERSN_NUM=? AND MODEL_TYPE_ID =" + 
						"  (SELECT KEPLER_REF_ENTITY.ENTITY_TYPE_ID FROM KEPLER_REF_ENTITY WHERE ENTITY_VAL=?))" + 
						"  AND " + 
						"  MODEL_VERSN_ID=" + 
						"  (select MODEL_VERSN_ID from KEPLER_MODEL_MASTER WHERE MODEL_NM=? and MODEL_VERSN_NUM=? AND MODEL_TYPE_ID =" + 
						"  (SELECT KEPLER_REF_ENTITY.ENTITY_TYPE_ID FROM KEPLER_REF_ENTITY WHERE ENTITY_VAL=?))";
				PreparedStatement preparedStmt = con.prepareStatement(query);
				preparedStmt.setInt(1, accuracy);
				preparedStmt.setTimestamp(2, tm);
				preparedStmt.setString(3, modelComment);
				preparedStmt.setString(4, ModelName);
				preparedStmt.setInt(5, ModelVersion);
				preparedStmt.setString(6, ModelType);
				preparedStmt.setString(7, ModelName);
				preparedStmt.setInt(8, ModelVersion);
				preparedStmt.setString(9, ModelType);
				rowCount=preparedStmt.executeUpdate();
				con.close();
			}

			catch (Exception e) {
				// TODO: handle exception
				e.getStackTrace();
				return false;
			}
			if(rowCount!=0)
				return true;
			else 
				return false;
	}
	
	/*@Override
	public boolean updateModeldspublish(String ModelType, String ModelName, int ModelVersion)  { int rowCount;
			// TODO Auto-generated method stub
			try {
				Class.forName("com.mysql.jdbc.Driver");
				con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
				String query = "UPDATE KEPLER_MODEL_MASTER SET MODEL_STATUS='PUBLISHED_DS WHERE MODEL_TYPE_ID "
						+ "IN (SELECT ENTITY_TYPE_ID FROM KEPLER_REF_ENTITY WHERE ENTITY_VAL IN ? )"
						+ " AND MODEL_NM =? AND MODEL_VRSN_NUM=?'";
				System.out.println("UPDATE KEPLER_MODEL_MASTER SET MODEL_STATUS='PUBLISHED_DS WHERE MODEL_TYPE_ID "
						+ "IN (SELECT ENTITY_TYPE_ID FROM KEPLER_REF_ENTITY WHERE ENTITY_VAL IN ? )"
						+ " AND MODEL_NM =? AND MODEL_VRSN_NUM=?'");
				PreparedStatement preparedStmt = con.prepareStatement(query);
				rowCount=preparedStmt.executeUpdate();
				con.close();
			}
			catch (Exception e) {
				// TODO: handle exception
				e.getStackTrace();
				return false;
			}
			if(rowCount!=0)
				return true;
			else 
				return false;
	} */
	
	@Override
	public boolean SaveExecuteBuild(String modelType,String modelName,int modelVer, String kpi, String modelComment) {
		int rowCount;
		try {
			PreparedStatement preparedStmt = null;
			ResultSet rs =null;
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
			String modelVerId="SELECT MODEL_ID, MODEL_VERSN_ID FROM KEPLER_MODEL_MASTER WHERE MODEL_NM= '"+modelName+"' AND MODEL_VERSN_NUM="+modelVer;
			preparedStmt=con.prepareStatement(modelVerId);
			rs=preparedStmt.executeQuery();
			int modelId=0;
			int verId=0;
			while (rs.next()) 
			{
				modelId=rs.getInt(1);
				verId=rs.getInt(2);
			}
			String query = "UPDATE KEPLER_MODEL_EXECUTION SET MODEL_KPI_ACCURACY="+kpi+", MODEL_PERFOMANCE_CMNT='"+modelComment+"'  WHERE MODEL_ID="+modelId+" AND MODEL_VERSN_ID="+verId;
			System.out.println("update query"+query); 
			preparedStmt = con.prepareStatement(query);
		
			
			
			rowCount=preparedStmt.executeUpdate();
			con.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}


		if(rowCount!=0)
			return true;
		else 
			return false;
	}
	@Override
	public boolean SaveExecute(String modelType,String modelName,int modelVer, String remarks, String feedback) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
			
			PreparedStatement preparedStmt = null;
			
			
			ResultSet rs =null;
			
			
			Date date= new Date();
			long time = date.getTime();
			System.out.println("Time in Milliseconds: " + time);
			Timestamp ts = new Timestamp(time);
			System.out.println("Current Time Stamp: " + ts);
			
			String modelVerId="SELECT MODEL_VERSN_ID FROM KEPLER_MODEL_MASTER WHERE MODEL_NM='"+modelName+"' AND MODEL_VERSN_NUM="+modelVer;
			
		    preparedStmt=con.prepareStatement(modelVerId);
			System.out.print("select ver"+modelVerId);
			rs=preparedStmt.executeQuery();
			int maxId=0;
			while (rs.next()) 
				maxId=rs.getInt(1);
			
			String insert="INSERT INTO KEPLER_MODEL_FEEDBACK(MODEL_CONSUMPTION_ID,RUN_ID,REMARKS,USER_ID,SHARE,RATING,CREATED_BY,CREATED_DTM,UPDATED_BY,MODEL_FEEDBACK_ID,MODEL_VRSN_ID)" + 
					"values (?,?,?,?,?,?,?,?,?,?,?)";
			preparedStmt=con.prepareStatement(insert);
//			preparedStmt.setInt(1, maxId);
			preparedStmt.setInt(1,1);
			preparedStmt.setInt(2,1);
			preparedStmt.setString(3,remarks);
			preparedStmt.setInt(4,1);
			preparedStmt.setString(5,feedback);
			preparedStmt.setInt(6,1);
			preparedStmt.setString(7,"admin");
			preparedStmt.setTimestamp(8, ts);
			preparedStmt.setString(9,"admin");
			preparedStmt.setInt(10, 1);
			preparedStmt.setInt(11, maxId);
			preparedStmt.execute();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}


		return true;
	}
	
	@Override
	public HashMap<Integer,String> getRoleNames() throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		//System.out.println("inside getmodelnm");
		HashMap<Integer,String> roleNm= new HashMap<Integer,String>();
		Statement stmt=con.createStatement();  
		ResultSet rs=stmt.executeQuery("SELECT ROLE_ID,ROLE_NM FROM KEPLER_ROLE_MASTER");

		while(rs.next()) {
			roleNm.put(rs.getInt(1), rs.getString(2));
			
		}
		return roleNm;
	}
	
	@Override
	public boolean createRole(String roleName,String schema[]) {

		try {
			PreparedStatement preparedStmt = null;
			ResultSet rs =null;
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
			
			
			
			String insert="INSERT INTO KEPLER_ROLE_MASTER(ROLE_NM,CREATED_BY,CREATED_DTM,UPDATED_BY,UPDATED_DTM)" + 
					"values (?,?,?,?,?)";
			
			Date date= new Date();
			long time = date.getTime();
			System.out.println("Time in Milliseconds: " + time);
			Timestamp ts = new Timestamp(time);
			System.out.println("Current Time Stamp: " + ts);
			
			preparedStmt=con.prepareStatement(insert);
			preparedStmt.setString(1,roleName);
			preparedStmt.setString(2,"admin");
			preparedStmt.setTimestamp(3, ts);
			preparedStmt.setString(4, "admin");
			preparedStmt.setTimestamp(5, ts);
			boolean status=preparedStmt.execute();
			
			
			String insert01="INSERT INTO KEPELR_ROLE_FEATURE_MAP(ROLE_ID,FEATURE_ID,CREATED_BY,CREATED_DTM,UPDATED_BY,UPDATED_DTM)"+
				"select a.ROLE_ID,b.FEATURE_ID,a.CREATED_BY,a.CREATED_DTM,a.UPDATED_BY,a.UPDATED_DTM from KEPLER_ROLE_MASTER a,KEPLER_FEATURE_MASTER b where a.ROLE_NM=? and b.FEATURE_NM=?";
			    con.setAutoCommit(false);//commit trasaction manually
				preparedStmt=con.prepareStatement(insert01);
				
				for(String model_type:schema)
				{
				preparedStmt.setString(1,roleName);
				preparedStmt.setString(2,model_type.replaceAll("[\\[\\]\"]", ""));
				preparedStmt.addBatch();
				}
				preparedStmt.executeBatch();
                
				con.commit();
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}


		return true;
	}
	
	
	@Override
	public boolean createModel(String modelType, String modelName, String modelLibraries, String modelDesc,
			String modelTemplate) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
			String selectModelType="select KEPLER_REF_ENTITY.ENTITY_TYPE_ID FROM KEPLER_REF_ENTITY where ENTITY_VAL=?";
			PreparedStatement preparedStmt = null;
			preparedStmt=con.prepareStatement(selectModelType);
			preparedStmt.setString(1,modelType);
			ResultSet rs =null;
			rs=preparedStmt.executeQuery();
			int typeId = 0;
			while (rs.next()) 
				typeId=rs.getInt(1);
			String selectTemplateType="SELECT TMPLT_ID FROM KEPLER_TEMPLATE_MASTER WHERE TMPLT_NM= ?";
			preparedStmt=con.prepareStatement(selectModelType);
			preparedStmt.setString(1,modelTemplate);
			rs=preparedStmt.executeQuery();
			int templateId =0;
			Date date= new Date();
			long time = date.getTime();
			System.out.println("Time in Milliseconds: " + time);
			Timestamp ts = new Timestamp(time);
			System.out.println("Current Time Stamp: " + ts);
			while (rs.next()) 
				templateId=rs.getInt(1);
			String modelVerId="SELECT MAX(MODEL_VERSN_ID) FROM KEPLER_MODEL_MASTER";
			preparedStmt=con.prepareStatement(modelVerId);
			rs=preparedStmt.executeQuery();
			int maxId=0;
			while (rs.next()) 
				maxId=rs.getInt(1);
			maxId+=1;
			String insert="INSERT INTO KEPLER_MODEL_MASTER(TMPLT_ID,MODEL_TYPE_ID,MODEL_NM,MODEL_DESC,MODEL_LANG,MODEL_STATUS,GCP_PROJ_ID,KEPLER_PROJ_ID,CREATED_BY,CREATED_DTM,UPDATED_BY,MODEL_VERSN_NUM,MODEL_VERSN_ID)" + 
					"values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
			preparedStmt=con.prepareStatement(insert);
			preparedStmt.setInt(1,templateId);
			preparedStmt.setInt(2,typeId);
			preparedStmt.setString(3,modelName);
			preparedStmt.setString(4, modelDesc);
			preparedStmt.setString(5,"PYTHON" );
			preparedStmt.setString(6,"IN-PROGRESS");
			preparedStmt.setInt(7,1);
			preparedStmt.setInt(8,1);
			//	preparedStmt.setString(9, modelLibraries);
			preparedStmt.setString(9,"admin");
			preparedStmt.setTimestamp(10, ts);
			preparedStmt.setString(11, "admin");
			preparedStmt.setInt(12, 1);
			preparedStmt.setInt(13, maxId);
			preparedStmt.execute();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}


		return true;
	}

	@Override
	public Map<String,Object> getmodelView(String ModelName,int ModelVersion) throws Exception
	{			Map<String,Object> map = new LinkedHashMap<String, Object>();

	try {
		
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		//return true;
		Statement stmt=con.createStatement();  
		//String s="SELECT MODEL_NM,MODEL_TYPE_ID,MODEL_ID,MODEL_VERSN_ID,TMPLT_ID,PROJ_SRVC_ACCT_MAP_ID,MODEL_VERSN_NUM,MODEL_DESC,MODEL_LANG,MODEL_STATUS,GCP_PROJ_ID,KEPLER_PROJ_ID,MODEL_USER_REMARKS,INPUT_DATASET_TYPE,INPUT_LIB_LST,CREATED_BY,CREATED_DTM,UPDATED_BY,UPDATED_DTM FROM KEPLER_MODEL_MASTER WHERE MODEL_VERSN_ID='"+ModelVersion+"' AND MODEL_NM='"+ModelName+"'";
		String s="SELECT a.MODEL_NM,b.ENTITY_VAL,a.MODEL_STATUS,a.MODEL_DESC,a.MODEL_VERSN_NUM  FROM KEPLER_MODEL_MASTER a,KEPLER_REF_ENTITY b WHERE a.MODEL_VERSN_ID='"+ModelVersion+"' "
				+ "AND a.MODEL_NM='"+ModelName+"' AND a.MODEL_TYPE_ID=b.ENTITY_TYPE_ID";
		ResultSet rs=stmt.executeQuery(s);

		while(rs.next())
		{
	/*	map.put("modelName",rs.getString(1));
			map.put("modelTypId",rs.getInt(2));
			map.put("modelId",rs.getInt(3));
			map.put("modelVerId",rs.getInt(4));
			map.put("tmpltId",rs.getInt(5));
			map.put("projSrvcId",rs.getInt(6));
			map.put("modelVerNum",rs.getInt(7));
			map.put("modelDesc",rs.getString(8));
			map.put("modelLang",rs.getString(9));
			map.put("modelStatus",rs.getString(10));
			map.put("gcpProjId",rs.getInt(11));
			map.put("keplerProjId",rs.getInt(12));
			map.put("modelUserRmks",rs.getString(13));
			map.put("inputDatasetTyp",rs.getString(14));
			map.put("inputLib",rs.getString(15));
			map.put("createdBy",rs.getString(16));
			map.put("createdTime",rs.getString(17));
			map.put("updatedBy",rs.getString(18));
			map.put("updatedTime",rs.getString(19)); */
			map.put("modelName",rs.getString(1));
			map.put("modelTypId",rs.getString(2));
			map.put("modelStatus",rs.getString(3));
			map.put("modelDesc",rs.getString(4));
			map.put("modelVerNum",rs.getInt(5));


		}
		

	}
	catch(Exception e) {
		e.printStackTrace();
		//return false;
	}

	return map;
	}

	@Override
	public List<String> getFeatures(int roleId) throws Exception {
				Class.forName("com.mysql.jdbc.Driver");
				con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
				//System.out.println("inside getmodelnm");
				PreparedStatement preparedStmt = null;
				
				List<String> featureNum= new ArrayList<String>();
				String featuresQuery="select FEATURE_NM from KEPLER_FEATURE_MASTER where FEATURE_ID in (select FEATURE_ID from KEPELR_ROLE_FEATURE_MAP where ROLE_ID=?) and FEATURE_NM LIKE '%Model%'";
				
				preparedStmt=con.prepareStatement(featuresQuery);
				preparedStmt.setInt(1,roleId);
				
				
				ResultSet rs =null;
				rs=preparedStmt.executeQuery();
				
				while (rs.next())
				{
					featureNum.add(rs.getString(1).replaceAll("_", " "));
				}
					
				List<String> distinctList=featureNum.stream().distinct().collect(Collectors.toList());	 
                
				
		return distinctList;
	}

	@Override
	public boolean modifyRole(String roleName, String[] schema) {
		
		try {
			PreparedStatement preparedStmt = null;
			ResultSet rs =null;
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
			
			String deleteQuery="DELETE FROM KEPELR_ROLE_FEATURE_MAP WHERE ROLE_ID=?";
			
			preparedStmt=con.prepareStatement(deleteQuery);
			preparedStmt.setInt(1,Integer.parseInt(roleName));
			con.setAutoCommit(false);//commit trasaction manually
			boolean status=preparedStmt.execute();
			
			String insertRoleMap="INSERT INTO KEPELR_ROLE_FEATURE_MAP(ROLE_ID,FEATURE_ID,CREATED_BY,CREATED_DTM,UPDATED_BY,UPDATED_DTM) " + 
							"select a.ROLE_ID,b.FEATURE_ID,a.CREATED_BY,a.CREATED_DTM,a.UPDATED_BY,CURRENT_TIMESTAMP() as UPDATED_DTM from KEPLER_ROLE_MASTER a,KEPLER_FEATURE_MASTER b where a.ROLE_ID=? and b.FEATURE_NM=?";
			
			
			//con.setAutoCommit(false);//commit trasaction manually
			preparedStmt=con.prepareStatement(insertRoleMap);
			
			for(String model_type:schema)
			{
			preparedStmt.setInt(1,Integer.parseInt(roleName));
			preparedStmt.setString(2,model_type.replaceAll("[\\[\\]\"]", ""));
			preparedStmt.addBatch();
			}
			preparedStmt.executeBatch();
            
			con.commit();
			
			
			
			
			
		}catch(Exception e)
		{
			
		}
		return true;
	}

	@Override
	public List<Role> listRoles() throws Exception {
		ArrayList<Role> roles = new ArrayList<Role>();
		String sql = "select role_id,role_nm from KEPLER_ROLE_MASTER order by role_nm";
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			if (conn == null || conn.isClosed()) {
				conn = DriverManager.getConnection(mysql_connection_string, mysql_username, mysql_password);
			}

			PreparedStatement pstm = conn.prepareStatement(sql);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				Role role = new Role();
				role.setRoleId(rs.getInt("role_id"));
				role.setRoleName(rs.getString("role_nm"));
				roles.add(role);
			}
			pstm.close();
			rs.close();
		} catch (Exception e) {
			throw e;
		} finally {
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
		}
		return roles;
	}

	@Override

	public List<UserDataTable> listUsers() throws Exception {
		ArrayList<UserDataTable> users = new ArrayList<UserDataTable>();
		String sql = "select user.USER_ID, user.PS_ID,  user.USER_DOMAIN,user.USER_NM, user.USER_EMAIL, user.UPDATED_BY, user.CREATED_DTM, user.UPDATED_DTM, role.ROLE_ID, role.ROLE_NM \n"
				+ "	from KEPLER_USER_MASTER user \n"
				+ "	left join KEPLER_USER_ROLE_MAP map on map.USER_ID = user.USER_ID \n"
				+ "	left join KEPLER_ROLE_MASTER role on role.ROLE_ID = map.ROLE_ID";
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			if (conn == null || conn.isClosed()) {
				conn = DriverManager.getConnection(mysql_connection_string, mysql_username, mysql_password);
			}

			PreparedStatement pstm = conn.prepareStatement(sql);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				UserDataTable user = new UserDataTable();
				user.setPsId(rs.getString("PS_ID"));
				user.setUserId(rs.getInt("USER_ID"));
				user.setUserDomain(rs.getString("USER_DOMAIN"));
				user.setUserName(rs.getString("USER_NM"));
				user.setUserEmail(rs.getString("USER_EMAIL"));
				user.setUserUpdatedBy(rs.getString("UPDATED_BY"));
				user.setCreatedOn(rs.getTimestamp("CREATED_DTM"));
				user.setUpdatedOn(rs.getTimestamp("UPDATED_DTM"));
				user.setRoleId(rs.getInt("ROLE_ID"));
				user.setRoleName(rs.getString("ROLE_NM"));
				users.add(user);
			}
			pstm.close();
			rs.close();
		} catch (Exception e) {
			throw e;
		} finally {
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
		}
		return users;
	}

	@Override
	public boolean createuser(CreateUserDTO createUserDto) throws Exception {
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(mysql_connection_string, mysql_username, mysql_password);
			conn.setAutoCommit(false);
			String qInsertUser = "insert into KEPLER_USER_MASTER (USER_DOMAIN, PS_ID,  USER_NM, USER_EMAIL, CREATED_BY, UPDATED_BY) \n"
					+ " values (?,?,?,?,?,?)";

			PreparedStatement preparedStmt = conn.prepareStatement(qInsertUser, Statement.RETURN_GENERATED_KEYS);
			preparedStmt.setString(1, createUserDto.getUserDomain());
			preparedStmt.setString(2, createUserDto.getPsId());
			preparedStmt.setString(3, createUserDto.getUserName());
			preparedStmt.setString(4, createUserDto.getEmail());
			preparedStmt.setString(5, "admin");
			preparedStmt.setString(6, "admin");
			preparedStmt.executeUpdate();

			ResultSet rs = preparedStmt.getGeneratedKeys();
			rs.next();
			int createdUserId = rs.getInt(1);

			String qInsertRoleMap = "insert into KEPLER_USER_ROLE_MAP (ROLE_ID, USER_ID, CREATED_BY, UPDATED_BY )"
					+ " values (?,?,?,?)";

			PreparedStatement ps2 = conn.prepareStatement(qInsertRoleMap);
			ps2.setInt(1, createUserDto.getRoleId());
			ps2.setInt(2, createdUserId);
			ps2.setString(3, "admin");
			ps2.setString(4, "admin");
			int upatedRows = ps2.executeUpdate();
			if (upatedRows == 1) {
				conn.commit();
				return true;
			} else {
				conn.rollback();
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
			if (conn != null && !conn.isClosed()) {
				conn.rollback();
			}
			return false;
		} finally {
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
		}

	}

	@Override
	public boolean updateUser(UpdateUserDTO updateUserDto) throws Exception {
		Connection conn = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(mysql_connection_string, mysql_username, mysql_password);
			conn.setAutoCommit(false);
			String qUpdateUser = "update KEPLER_USER_MASTER set USER_DOMAIN = ?, USER_NM = ?, USER_EMAIL = ?, UPDATED_BY = ? "
					+ " where USER_ID = ? ";
			String qUpdateRole = "update KEPLER_USER_ROLE_MAP set ROLE_ID = ? where ROLE_ID= ? and USER_ID = ? ";
			boolean commitFlag = true;
			// update details other than role
			if (!StringUtils.equalsAny("", updateUserDto.getUserDomain(), updateUserDto.getUserName(),
					updateUserDto.getEmail())) {
				PreparedStatement preparedStmt = conn.prepareStatement(qUpdateUser);
				preparedStmt.setString(1, updateUserDto.getUserDomain());
				preparedStmt.setString(2, updateUserDto.getUserName());
				preparedStmt.setString(3, updateUserDto.getEmail());
				preparedStmt.setString(4, "admin");
				preparedStmt.setInt(5, updateUserDto.getUserId());
				if (preparedStmt.executeUpdate() != 1) {
					commitFlag = false;
				}
			}
			// update role details
			if (updateUserDto.getOldRoleId() != updateUserDto.getNewRoleId() && updateUserDto.getNewRoleId() != 0) {

				PreparedStatement psUpdate = conn.prepareStatement(qUpdateRole);
				psUpdate.setInt(1, updateUserDto.getNewRoleId());
				psUpdate.setInt(2, updateUserDto.getOldRoleId());
				psUpdate.setInt(3, updateUserDto.getUserId());
				if (psUpdate.executeUpdate()!=1) {
					commitFlag = false;
				}
			}
			if (commitFlag) {
				conn.commit();
			} else {
				conn.rollback();
			}
			return commitFlag;

		} catch (Exception e) {
			e.printStackTrace();
			if (conn != null && !conn.isClosed()) {
				conn.rollback();
			}
			return false;
		} finally {
			if (conn != null && !conn.isClosed()) {
				conn.close();
			}
		}

	}
	
	int updateDsModel(String modelType,String modelName, int modelVer,String status) {
		int cnt=0;
		PreparedStatement preparedStmt = null;
		System.out.println(modelType+modelName+modelVer+status);
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
			
			String query = "UPDATE KEPLER_MODEL_MASTER SET MODEL_STATUS='PUBLISHED_DS',UPDATED_DTM=CURRENT_TIMESTAMP"
					+ " WHERE MODEL_TYPE_ID " 
					+ "IN (SELECT ENTITY_TYPE_ID FROM KEPLER_REF_ENTITY WHERE ENTITY_VAL = ? )"
					+ " AND MODEL_NM =? AND MODEL_VERSN_NUM=? AND MODEL_STATUS=?";
			
			System.out.println("UPDATE KEPLER_MODEL_MASTER SET MODEL_STATUS='PUBLISHED_DS',UPDATED_DTM=CURRENT_TIMESTAMP"
					+ "WHERE MODEL_TYPE_ID "
					+ "IN (SELECT ENTITY_TYPE_ID FROM KEPLER_REF_ENTITY WHERE ENTITY_VAL = ? )"
					+ " AND MODEL_NM =? AND MODEL_VERSN_NUM=? AND MODEL_STATUS=?");

			//System.out.println("update query:-"+query); 
			preparedStmt = con.prepareStatement(query);
			preparedStmt.setString(4, status);
			preparedStmt.setString(1, modelType);
			preparedStmt.setString(2, modelName);
			preparedStmt.setInt(3, modelVer);
			//preparedStmt = con.prepareStatement(query);
			cnt=preparedStmt.executeUpdate();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;
	}
	
	int updateBzModel(String modelType,String modelName, int modelVer,String status) {
		int cnt=0;
		PreparedStatement preparedStmt = null;
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
			
			String query = "UPDATE KEPLER_MODEL_MASTER SET MODEL_STATUS='PUBLISHED_BZ',UPDATED_DTM=CURRENT_TIMESTAMP"
					+ " WHERE MODEL_TYPE_ID "
					+ "IN (SELECT ENTITY_TYPE_ID FROM KEPLER_REF_ENTITY WHERE ENTITY_VAL = ? )"
					+ " AND MODEL_NM =? AND MODEL_VERSN_NUM=? AND MODEL_STATUS=?";
			
			System.out.println("UPDATE KEPLER_MODEL_MASTER SET MODEL_STATUS='PUBLISHED_BZ',UPDATED_DTM=CURRENT_TIMESTAMP"
					+ "WHERE MODEL_TYPE_ID "
					+ "IN (SELECT ENTITY_TYPE_ID FROM KEPLER_REF_ENTITY WHERE ENTITY_VAL = ? )"
					+ " AND MODEL_NM =? AND MODEL_VERSN_NUM=? AND MODEL_STATUS=?");

			//System.out.println("update query:-"+query);
			preparedStmt = con.prepareStatement(query);
			preparedStmt.setString(4, status);
			preparedStmt.setString(1, modelType);
			preparedStmt.setString(2, modelName);
			preparedStmt.setInt(3, modelVer);			
			cnt=preparedStmt.executeUpdate();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return cnt;
	}
	
	@Override
public boolean publishModel(String modelType, String modelName, int modelVer,String check) {
	// TODO Auto-generated method stub
	int rowCount = 0;
	try {
		
		System.out.println("check:-"+check);
		if(check.equalsIgnoreCase("DS")) {
			
			rowCount=updateDsModel(modelType,modelName,modelVer,"AWT_APRVL_PUBLISH_DS");	
		}
		
		else if(check.equalsIgnoreCase("BU"))
		rowCount=updateBzModel(modelType,modelName,modelVer,"AWT_APRVL_PUBLISH_BZ");
		else if(check.equalsIgnoreCase("BOTH"))
		{
			rowCount=updateDsModel(modelType,modelName,modelVer,"AWT_APRVL_PUBLISH_DS");
			rowCount=updateBzModel(modelType,modelName,modelVer,"AWT_APRVL_PUBLISH_BZ");
		}
	
	}
	catch(Exception e) {
		e.printStackTrace();
	}
	if(rowCount!=0)
		return true;
	else 
		return false;
	}
	
	
	@Override

	public boolean createProject(String projectNm, String projectDesc, String projOwner, String g_projNm, String g_projectDesc,
			String g_projOwner) throws Exception {
		// TODO Auto-generated method stub
		
		PreparedStatement preparedStmt = null;
		ResultSet rs =null;
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
	
		String insert="INSERT INTO KEPLER_PROJECT_MASTER(PROJ_TYPE,PROJ_NM,PROJ_OWNER,PROJ_DESC,GCP_KPROJ_LINK,CREATED_BY,CREATED_DTM,UPDATED_BY,UPDATED_DTM)" + 
				"values (?,?,?,?,?,?,?,?,?)";
		
		Date date= new Date();
		long time = date.getTime();
		System.out.println("Time in Milliseconds: " + time);
		Timestamp ts = new Timestamp(time);
		System.out.println("Current Time Stamp: " + ts);
		con.setAutoCommit(false);//commit trasaction manually
		preparedStmt=con.prepareStatement(insert);
		preparedStmt.setString(1,"KEPLER");
		preparedStmt.setString(2,projectNm);
		preparedStmt.setString(3, projOwner);
		preparedStmt.setString(4, projectDesc);
		preparedStmt.setString(5, g_projNm);
		preparedStmt.setString(6,"admin");
		preparedStmt.setTimestamp(7, ts);
		preparedStmt.setString(8,"admin");
		preparedStmt.setTimestamp(9, ts);
		preparedStmt.addBatch();
		
		//for google details
		preparedStmt.setString(1,"GCP");
		preparedStmt.setString(2,g_projNm);
		preparedStmt.setString(3, g_projectDesc);
		preparedStmt.setString(4, g_projOwner);
		preparedStmt.setString(5, null);
		preparedStmt.setString(6,"admin");
		preparedStmt.setTimestamp(7, ts);
		preparedStmt.setString(8,"admin");
		preparedStmt.setTimestamp(9, ts);
		preparedStmt.addBatch();
		
		preparedStmt.executeBatch();
        
		con.commit();
		
			
		
		return true;
	}

	@Override
	public HashMap<Integer, String> getProjectNames() throws Exception {
		// TODO Auto-generated method stub
				Class.forName("com.mysql.jdbc.Driver");
				con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
				//System.out.println("inside getmodelnm");
				HashMap<Integer,String> roleNm= new HashMap<Integer,String>();
				Statement stmt=con.createStatement();  
				ResultSet rs=stmt.executeQuery("SELECT PROJ_ID,PROJ_NM FROM KEPLER_PROJECT_MASTER where PROJ_TYPE='KEPLER'");

				while(rs.next()) {
					roleNm.put(rs.getInt(1), rs.getString(2));
					
				}
				return roleNm;
	}

	@Override
	public HashMap<String,String> getProjectdetails(int projId) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		//System.out.println("inside getmodelnm");
		PreparedStatement preparedStmt = null;
		HashMap<String,String> projMap= new HashMap<String,String>();
		
		String projectQuery="select PROJ_ID,PROJ_NM,PROJ_DESC,PROJ_OWNER,GCP_KPROJ_LINK from KEPLER_PROJECT_MASTER WHERE PROJ_ID=?"; 
		
		preparedStmt=con.prepareStatement(projectQuery);
		preparedStmt.setInt(1,projId);
		
		
		ResultSet rs =null;
		rs=preparedStmt.executeQuery();
		String GCP_KPROJ_LINK=null;
		while (rs.next())
		{
			
			projMap.put("KprojectId"," "+rs.getInt(1));
			projMap.put("projectNm", rs.getString(2));
			projMap.put("projectDesc", rs.getString(3));
			projMap.put("projOwner", rs.getString(4));
			GCP_KPROJ_LINK=rs.getString(5);
									
		}
		
      String gcp_Query="select PROJ_NM,PROJ_DESC,PROJ_OWNER from KEPLER_PROJECT_MASTER WHERE PROJ_NM=? and PROJ_TYPE='GCP'"; 
		
		preparedStmt=con.prepareStatement(gcp_Query);
		preparedStmt.setString(1,GCP_KPROJ_LINK);
		
		rs=preparedStmt.executeQuery();
		if(rs.next())
		{
		projMap.put("projId1",rs.getString(1));
		projMap.put("projNm",rs.getString(2));
		projMap.put("G_projOwner",rs.getString(3));
		}
		
return projMap;
	}

	@Override
	public boolean checkProjectName(String projectNm) throws Exception {
		// TODO Auto-generated method stub
		
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		//System.out.println("inside getmodelnm");
		PreparedStatement preparedStmt = null;
		HashMap<String,String> projMap= new HashMap<String,String>();
		
		String projectQuery="select count(1) from KEPLER_PROJECT_MASTER WHERE PROJ_NM=?"; 
		
		preparedStmt=con.prepareStatement(projectQuery);
		preparedStmt.setString(1,projectNm);
		ResultSet rs=preparedStmt.executeQuery();
		rs.first();
		int count=rs.getInt(1);
		System.out.println("count : "+count);
		boolean status=(count==0)?false:true;
		return status;
	}

	@Override
	public boolean updateProject(int KprojectId, String projectNm, String projectDesc, String projOwner,
			String g_projNm, String g_projdesc, String g_projOwner) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(mysql_connection_string,mysql_username,mysql_password);
		String updateQ = "UPDATE KEPLER_PROJECT_MASTER SET PROJ_NM=?, PROJ_OWNER=?,  PROJ_DESC=? , UPDATED_DTM=CURRENT_TIMESTAMP() WHERE PROJ_ID="+KprojectId;
		String updateQ01 = "UPDATE KEPLER_PROJECT_MASTER SET PROJ_NM=?, PROJ_OWNER=?,  PROJ_DESC=? , UPDATED_DTM=CURRENT_TIMESTAMP() WHERE PROJ_NM=?";
		
		
			
		
		PreparedStatement preparedStmt=null;
		con.setAutoCommit(false);//commit trasaction manually
		preparedStmt= con.prepareStatement(updateQ);
		preparedStmt.setString(1, projectNm);
		preparedStmt.setString(2, projOwner);
		preparedStmt.setString(3, projectDesc);
		preparedStmt.addBatch();
		
		
		
		preparedStmt= con.prepareStatement("select GCP_KPROJ_LINK from KEPLER_PROJECT_MASTER where PROJ_ID=?");
		preparedStmt.setInt(1, KprojectId);
		ResultSet rs=preparedStmt.executeQuery();
		String projNum="";
		if(rs.next())
		{
			projNum=rs.getString("GCP_KPROJ_LINK");	
		}
		preparedStmt = con.prepareStatement(updateQ01);
		preparedStmt.setString(1, g_projNm);
		preparedStmt.setString(2, g_projOwner);
		preparedStmt.setString(3, g_projdesc);
		preparedStmt.setString(4, projNum);
		preparedStmt.addBatch();
		preparedStmt.executeBatch();
		con.commit();
		
		return true;
	}


}