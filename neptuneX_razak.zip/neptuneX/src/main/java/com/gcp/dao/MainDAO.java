package com.gcp.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.gcp.dto.UserAccount;
import com.google.cloud.bigquery.BigQuery;

public interface MainDAO {
	
	ArrayList<UserAccount> getUserAccount() throws Exception;
	UserAccount findUserFromId(String user_id) throws Exception;
	List<String> findUserRoles(String user_id) throws Exception;
	ArrayList<String> getModelType() throws Exception;
	ArrayList<String> getModelTypeBZ() throws Exception;
	ArrayList<String> getModelTypeDS() throws Exception;
	ArrayList<String> getModelName(String modelType) throws Exception;
	ArrayList<String> getModelNameBZ(String modelType) throws Exception;
	ArrayList<String> getModelNameDS(String modelType) throws Exception;
	ArrayList<String> getModelVer(String modelType,String modelName) throws Exception;
	ArrayList<String> getModelTmpl() throws Exception;
	ArrayList<String> getGoogleApi() throws Exception;
	ArrayList<String> getModelLibraries() throws Exception;
	 Map<String,ArrayList<Object>> getData() throws Exception;
	 boolean updateModel(String modelType,String modelName,int modelVersion,String time,int accuracy,String modelComment) throws Exception;
	 boolean createModel(String modelType,String modelName,String modelLibraries,String modelDesc,String modelTemplate) throws Exception;
//	 ArrayList<String> getTableList( String datasetName,BigQuery bigquery) throws Exception ;
//	 public BigQuery returnBigqueryObject() throws Exception;
	 Map<String,Object> getmodelView(String ModelName,int ModelVersion) throws Exception;
	 Map<String,ArrayList<Object>> getViewTable(String ModelType,String ModelName) throws Exception;
	 boolean SaveExecute(String modelType,String modelName,int modelVer, String remarks, String feedback);
	 boolean SaveExecuteBuild(String modelType, String modelName, int modelVer, String kpi, String modelComment);
	 boolean publishModel(String modelType, String modelName, int modelVer, String check);
	ArrayList<String> getModelType1(String createdby) throws Exception;
	ArrayList<String> getModelName1(String modelTyp,String createdby) throws Exception;
	ArrayList<String> getModelVer1(String modelType,String modelName,String createdby) throws Exception;
	Map<String,Object> getModelEdit(String ModelType,String ModelName,String modelVersion) throws Exception;
	List<String> getModelType2(String createdBy) throws Exception;
	List<String> getModelName2(String modelType, String createdBy) throws Exception;
	List<String> getModelVer2(String modelType, String modelName, String createdBy)throws Exception;
	ArrayList<String> getModelTypeEdit() throws Exception;
	ArrayList<String> getModelNameEdit(String modelTyp, String createdby) throws Exception;
	ArrayList<String> getModelVerEdit(String modelType, String modelName, String createdby) throws Exception;
	int getNextModelVer(String modelType, String modelName, String createdby) throws Exception;
 Map<String,ArrayList<Object>> getGraphValues(String modelType,String modelName,String kpi) throws Exception;
	 boolean storeFeedback(String modelType,String modelName,String feedback,int rating) throws Exception;
	 ArrayList<String> getKpiValues() throws Exception;
	 ArrayList<String> getModelTypeView(String createdby) throws Exception;
	 ArrayList<String> getModelNameView(String modelType,String createdby) throws Exception;
}
