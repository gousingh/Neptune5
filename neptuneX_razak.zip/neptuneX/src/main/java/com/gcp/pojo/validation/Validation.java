package com.gcp.pojo.validation;

public class Validation {

	private Boolean isValid;
	private String message;

	public Validation(Boolean isValidated, String message) {
		this.isValid = isValidated;
		this.message = message;
	}
	
	public Boolean getIsValid() {
		return isValid;
	}

	public void setIsValid(Boolean isValidated) {
		this.isValid = isValidated;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}
