package com.gcp.pojo.adminpanel;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonFormat;

public class UserDataTable {
	
	private String psId;
	private Integer userId;
	private String userDomain;
	private String userName;
	private String userEmail;
	private String userUpdatedBy;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm")
	private Timestamp createdOn;
	
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm")
	private Timestamp updatedOn;
	private Integer roleId;
	private String roleName;

	public UserDataTable() {
	}
	
	public UserDataTable(Integer userId, String userDomain, String userName, String userEmail, String userUpdatedBy,
			Timestamp createdOn, Timestamp updatedOn, Integer roleId, String roleName) {
		this.userId = userId;
		this.userDomain = userDomain;
		this.userName = userName;
		this.userEmail = userEmail;
		this.userUpdatedBy = userUpdatedBy;
		this.createdOn = createdOn;
		this.updatedOn = updatedOn;
		this.roleId = roleId;
		this.roleName = roleName;
	}

	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserUpdatedBy() {
		return userUpdatedBy;
	}
	public void setUserUpdatedBy(String userUpdatedBy) {
		this.userUpdatedBy = userUpdatedBy;
	}
	public Timestamp getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}
	public Timestamp getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Timestamp updatedOn) {
		this.updatedOn = updatedOn;
	}
	public Integer getRoleId() {
		return roleId;
	}
	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getUserDomain() {
		return userDomain;
	}

	public void setUserDomain(String userDomain) {
		this.userDomain = userDomain;
	}

	public String getPsId() {
		return psId;
	}

	public void setPsId(String psId) {
		this.psId = psId;
	}
	
}
