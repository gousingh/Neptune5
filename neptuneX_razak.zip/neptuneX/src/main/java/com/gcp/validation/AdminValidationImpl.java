package com.gcp.validation;

public interface AdminValidationImpl {
	
	
}
