package com.gcp.validation;

import com.gcp.pojo.validation.Validation;

public interface AdminValidation {
	
	public Validation validateUserCreation();
	
}
