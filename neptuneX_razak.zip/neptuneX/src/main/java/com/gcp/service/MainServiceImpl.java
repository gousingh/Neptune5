package com.gcp.service;

import java.util.List;
import java.util.Map;
import java.sql.Timestamp;
import java.util.ArrayList;

import com.gcp.dao.MainDAO;
import com.gcp.dto.UserAccount;
import com.google.cloud.bigquery.BigQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MainServiceImpl implements MainService{

	@Autowired
	MainDAO loginDAO;

	@Override
	public ArrayList<UserAccount> getUserAccount() throws Exception {
		return loginDAO.getUserAccount();
	}

	@Override
	public UserAccount findUserFromId(String user_id) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.findUserFromId(user_id);
	}

	@Override
	public List<String> findUserRoles(String user_id) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.findUserRoles(user_id);
	}

	@Override
	public ArrayList<String> getModelType() throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelType();
	}


	@Override
	public ArrayList<String> getModelName(String modelTyp) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelName(modelTyp);
	}

	@Override
	public ArrayList<String> getModelVer(String modelType, String modelName) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelVer(modelType, modelName);
	}

	@Override
	public Map<String, ArrayList<Object>> getData() throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getData();
	}

	@Override
	public ArrayList<String> getModelTmpl() throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelTmpl();
	}
	
	@Override
	public boolean updateModel(String ModelType, String ModelName, int ModelVersion, String time, int accuracy,
			String modelComment) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.updateModel(ModelType, ModelName, ModelVersion, time, accuracy, modelComment);
	}

	@Override
	public boolean createModel(String modelType, String modelName, String modelLibraries, String modelDesc,
			String modelTemplate) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.createModel(modelType, modelName, modelLibraries, modelDesc, modelTemplate);
	}

//	@Override
//	public ArrayList<String> getTableList(String datasetName, BigQuery bigquery) throws Exception {
//		// TODO Auto-generated method stub
//		return loginDAO.getTableList(datasetName, bigquery);
//	}
//
//	@Override
//	public BigQuery returnBigqueryObject() throws Exception {
//		// TODO Auto-generated method stub
//		return loginDAO.returnBigqueryObject();
//	}
//
	@Override
	public Map<String,Object> getmodelView(String ModelName,int ModelVersion) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getmodelView(ModelName,ModelVersion);
	}
	
	@Override
	public Map<String,ArrayList<Object>> getViewTable(String ModelType,String ModelName) throws Exception{
		// TODO Auto-generated method stub
				return loginDAO.getViewTable(ModelType,ModelName);
	}
	
	@Override
	public boolean SaveExecute(String modelType,String modelName,int modelVer, String remarks, String feedback) {
		// TODO Auto-generated method stub
		return loginDAO.SaveExecute(modelType,modelName,modelVer, remarks, feedback);
	}

	@Override
	public boolean SaveExecuteBuild(String modelType, String modelName, int modelVer, String kpi,
			String modelComment) {
		// TODO Auto-generated method stub
		return loginDAO.SaveExecuteBuild(modelType, modelName, modelVer, kpi, modelComment);
	}

	@Override
	public boolean publishModel(String modelType, String modelName, int modelVer , String status ) {
		// TODO Auto-generated method stub
		return loginDAO.publishModel(modelType, modelName, modelVer, status);
	}
	
	@Override
	public ArrayList<String> getGoogleApi() throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getGoogleApi();
	}

	@Override
	public ArrayList<String> getModelLibraries() throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelLibraries();
	}

	@Override
	public ArrayList<String> getModelTypeBZ() throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelTypeBZ();
	}

	@Override
	public ArrayList<String> getModelTypeDS() throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelTypeDS();
	}

	@Override
	public ArrayList<String> getModelNameBZ(String modelType) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelNameBZ(modelType);
	}

	@Override
	public ArrayList<String> getModelNameDS(String modelType) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelNameDS(modelType);
	}

	@Override
	public ArrayList<String> getModelType1(String createdby) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelType1(createdby);
	}

	@Override
	public ArrayList<String> getModelName1(String modelTyp,String createdby) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelName1(modelTyp, createdby);
	}

	@Override
	public ArrayList<String> getModelVer1(String modelType, String modelName,String createdby) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelVer1(modelType, modelName, createdby);
	}
	
	@Override
	public Map<String,Object> getModelEdit(String modelType,String modelName,String modelVersion) throws Exception{
		// TODO Auto-generated method stub
				return loginDAO.getModelEdit(modelType,modelName,modelVersion);
	}

	@Override
	public List<String> getModelType2(String createdBy) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelType2(createdBy);
	}

	@Override
	public List<String> getModelName2(String modelType, String createdBy) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelName2(modelType, createdBy);
	}

	@Override
	public List<String> getModelVer2(String modelType, String modelName, String createdBy) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelVer2(modelType, modelName, createdBy);
	}

	@Override
	public List<String> getModelTypeEdit(String createdBy) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelTypeEdit();
	}

	@Override
	public List<String> getModelNameEdit(String modelType, String createdBy) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelNameEdit(modelType, createdBy);
	}

	@Override
	public List<String> getModelVerEdit(String modelType, String modelName, String createdBy) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelVerEdit(modelType, modelName, createdBy);
	}

	@Override
	public int getNextModelVer(String modelType, String modelName, String createdBy) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getNextModelVer(modelType, modelName, createdBy);
	}
	@Override
	public Map<String,ArrayList<Object>> getGraphValues(String modelType,String modelName,String kpi) throws Exception{
		// TODO Auto-generated method stub
				return loginDAO.getGraphValues(modelType, modelName,kpi);
	}
	
	@Override
	public boolean storeFeedback(String modelType,String modelName,String feedback,int rating) throws Exception{
		// TODO Auto-generated method stub
		return loginDAO.storeFeedback(modelType, modelName,feedback,rating);
	}
	
	@Override
	public ArrayList<String> getKpiValues() throws Exception{
		// TODO Auto-generated method stub
				return loginDAO.getKpiValues();
	}
	
	@Override
	public ArrayList<String> getModelTypeView(String createdby) throws Exception{
		// TODO Auto-generated method stub
				return loginDAO.getModelTypeView(createdby);
	}
	@Override
	public ArrayList<String> getModelNameView(String modelType,String createdby) throws Exception{
		// TODO Auto-generated method stub
				return loginDAO.getModelNameView(modelType, createdby);
	}
}
