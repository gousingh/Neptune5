package com.gcp.service;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.gcp.dto.UserAccount;
import com.google.api.gax.paging.Page;
import com.google.cloud.bigquery.BigQuery;
import com.google.cloud.bigquery.Dataset;
import com.google.cloud.bigquery.Job;
import com.google.cloud.bigquery.Table;
import com.google.cloud.bigquery.TableResult;
import com.google.cloud.storage.Storage;
import java.sql.Timestamp;

public interface BigqueryService {
	BigQuery returnBigqueryObject() throws Exception;
	Storage returnStorageObject() throws Exception;
	Dataset createDataset(String DatasetName, BigQuery bigquery) throws Exception;
	List<String> listDatasets(String projectId, BigQuery bigquery) throws Exception;
	boolean deleteDatasetFromId(String projectId, String datasetName, BigQuery bigquery) throws Exception;
	boolean deleteTableFromId(String projectId, String datasetName, String tableName, BigQuery bigquery) throws Exception;
	Page<Table> listTablesFromId(String projectId, String datasetName, BigQuery bigquery) throws Exception;
	long writeToTable(String datasetName, String tableName, String csvData, BigQuery bigquery) throws Exception;
	long writeFileToTable(String datasetName, String tableName, Path csvPath, String location, BigQuery bigquery) throws Exception;
	String createTable(String datasetName, String tableName, List<String> fieldList, BigQuery bigquery) throws Exception;
	Job writeRemoteFileToTable(String datasetName, String tableName, String sourceUri, BigQuery bigquery) throws Exception;
	TableResult listTableData(String datasetName, String tableName, BigQuery bigquery) throws Exception;
	void runQuery(String datasetName, String tableName, BigQuery bigquery) throws Exception;
	void runQueryPermanentTableAndDownload(String destinationDataset, String destinationTable, String format, String gcsUrl, String bucketName, String srcFilename, Path destFilePath, BigQuery bigquery)
			throws Exception;
	List<String> listTables(String datasetName, BigQuery bigquery) throws Exception;
	List<String> listTables1(String datasetName, BigQuery bigquery) throws Exception;
	List<String> getSchema(String datasetName, String tableName, BigQuery bigquery) throws Exception;
	boolean createMediaLink(String datasetName, String tableName, String profilingLib, String mediaLink,Timestamp timestamp) throws Exception;
	ArrayList<String> getProfilingLib(String datasetName,String tableName) throws Exception;
	Map<String,ArrayList<Object>> getMediaLinks(String datasetName,String tableName,String profilingLib) throws Exception;

	
	/////////////////////////////////////////////////////////////
	
	ArrayList<UserAccount> getUserAccount() throws Exception;
	UserAccount findUserFromId(String user_id) throws Exception;
	List<String> findUserRoles(String user_id) throws Exception;
	
	
}
