package com.gcp.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gcp.dao.AdminDAO;
import com.gcp.dto.CreateUserDTO;
import com.gcp.dto.UpdateUserDTO;
import com.gcp.dto.UserAccount;
import com.gcp.pojo.adminpanel.Role;
import com.gcp.pojo.adminpanel.UserDataTable;

@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	AdminDAO loginDAO;

	@Override
	public ArrayList<UserAccount> getUserAccount() throws Exception {
		return loginDAO.getUserAccount();
	}

	@Override
	public UserAccount findUserFromId(String user_id) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.findUserFromId(user_id);
	}

	@Override
	public List<String> findUserRoles(String user_id) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.findUserRoles(user_id);
	}

	@Override
	public ArrayList<String> getModelType() throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelType();
	}


	@Override
	public ArrayList<String> getModelName(String modelTyp) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelName(modelTyp);
	}

	@Override
	public ArrayList<String> getModelVer(String modelType, String modelName) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getModelVer(modelType, modelName);
	}

	@Override
	public Map<String, ArrayList<Object>> getData() throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getData();
	}

	@Override
	public boolean updateModel(String ModelType, String ModelName, int ModelVersion, long time, int accuracy,
			String modelComment) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.updateModel(ModelType, ModelName, ModelVersion, time, accuracy, modelComment);
	}
	
	/*@Override
	public boolean updateModeldspublish(String ModelType, String ModelName, int ModelVersion) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.updateModeldspublish(ModelType, ModelName, ModelVersion);
	} */

	@Override
	public boolean createModel(String modelType, String modelName, String modelLibraries, String modelDesc,
			String modelTemplate) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.createModel(modelType, modelName, modelLibraries, modelDesc, modelTemplate);
	}

	@Override
	public boolean createRole(String roleName,String schema[]){
		// TODO Auto-generated method stub
		return loginDAO.createRole(roleName,schema);
	}
	
	@Override
	public HashMap<Integer,String> getRoleNames() throws Exception
	{
		return loginDAO.getRoleNames();
	}
	
	@Override
	public List<String> getFeatures(int roleId) throws Exception
	{
		return loginDAO.getFeatures(roleId);
	}
	
//	@Override
//	public ArrayList<String> getTableList(String datasetName, BigQuery bigquery) throws Exception {
//		// TODO Auto-generated method stub
//		return loginDAO.getTableList(datasetName, bigquery);
//	}
//
//	@Override
//	public BigQuery returnBigqueryObject() throws Exception {
//		// TODO Auto-generated method stub
//		return loginDAO.returnBigqueryObject();
//	}
//
	@Override
	public Map<String,Object> getmodelView(String ModelName,int ModelVersion) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getmodelView(ModelName,ModelVersion);
	}
	@Override
	public boolean SaveExecute(String modelType,String modelName,int modelVer, String remarks, String feedback) {
		// TODO Auto-generated method stub
		return loginDAO.SaveExecute(modelType,modelName,modelVer, remarks, feedback);
	}

	@Override
	public boolean SaveExecuteBuild(String modelType, String modelName, int modelVer, String kpi,
			String modelComment) {
		// TODO Auto-generated method stub
		return loginDAO.SaveExecuteBuild(modelType, modelName, modelVer, kpi, modelComment);
	}

	@Override
	public ArrayList<String> getModelTmpl() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean modifyRole(String roleName, String[] schema) {
		// TODO Auto-generated method stub
		return loginDAO.modifyRole(roleName,schema);
	}
	
	@Override
	public List<Role> listRoles() throws Exception {
		return loginDAO.listRoles();
	}
	@Override
	public List<UserDataTable> listUsers() throws Exception {
		return loginDAO.listUsers();
	}
	
	@Override
	public Boolean createUser(CreateUserDTO createUserDto) throws Exception {
		return loginDAO.createuser(createUserDto);
	}
	
	@Override
	public Boolean updateUser(UpdateUserDTO updateUserDto) throws Exception {
		return loginDAO.updateUser(updateUserDto);
	}
	
	public boolean publishModel(String modelType, String modelName, int modelVer , String status ) {
		// TODO Auto-generated method stub
		return loginDAO.publishModel(modelType, modelName, modelVer, status);
	}
	
	@Override
	public boolean createProject(String projectNm, String projectDesc, String projOwner, String projId1, String projNm,
			String g_projOwner) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.createProject(projectNm, projectDesc,projOwner,projId1,projNm,g_projOwner);
	}

	@Override
	public HashMap<Integer, String> getProjectNames() throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getProjectNames();
	}

	@Override
	public HashMap<String,String> getProjectdetails(int projId) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.getProjectdetails(projId);
	}

	@Override
	public boolean checkProjectName(String projectNm) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.checkProjectName(projectNm);
	}

	@Override
	public boolean updateProject(int KprojectId, String projectNm, String projectDesc, String projOwner,
			String g_projNm, String g_projdesc, String G_projOwner) throws Exception {
		// TODO Auto-generated method stub
		return loginDAO.updateProject(KprojectId,projectNm, projectDesc,projOwner,g_projNm,g_projdesc,G_projOwner);
	}
}
