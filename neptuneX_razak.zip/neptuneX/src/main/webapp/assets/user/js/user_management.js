$(document).ready(function() {
	listroles();
	userTable();

	$('#psId').change(function() {
		$('#idValidationFlag').val("false");
		$(".fa-validate").hide();
		$('#validationMsg').text("Click Validate");
	});

	$('#validate').click(function() {
		$('#idValidationFlag').val("false");
		var psId = $('#psId').val();
		if (psId == "") {
			$('#validationMsg').text("PSID cannot be null...");
			return false;
		}
		$(this).hide();
		$("#edit").show();
		$("#psId").attr("disabled", "disabled");
		$(".fa-validate").hide();
		$('#validationMsg').text("Checking...");
		$.ajax({
			url : 'validatepsid',
			type : 'GET',
			data : {
				"psId" : $('#psId').val()
			},
			dataType : 'json',
			success : function(responseJson) {
				if (responseJson.isValid) {
					$('#idValid').show();
					$('#idValidationFlag').val("true");
				} else {
					$('#idNotValid').show();
				}
				$('#validationMsg').text(responseJson.message);
			}
		});

	});

	$('#edit').click(function() {
		$('#validate').show();
		$(this).hide();
		$("#psId").removeAttr("disabled");
	});

	$('#save').click(function() {
		$('#alertBox').hide();
		$(this).attr("disabled","disabled");
		var role = $('#role').val();
		var psId = $('#psId').val();
		var domain = $('#domain').val();
		var name = $('#name').val();
		var email = $('#email').val();
		if (role == null) {
			$('#alertBox').show();
			$('#alertBox').text("Kindly Select a Role");
			$(this).removeAttr("disabled");
		}
		if (psId == "") {
			$('#alertBox').show();
			$('#alertBox').text("Kindly Enter the User's PSID and click validate button");
			$(this).removeAttr("disabled");
		}

		$.ajax({
			url : 'createuser',
			type : 'POST',
			data : {
				"psId" : psId,
				"roleId" : role,
				"userDomain" : domain,
				"userName" : name,
				"email" : email
			},
			success : function() {
				initCreateForm();
				$('#alertBoxSuccess').show();
				$('#alertBoxSuccess').text("Successfully saved");
			},
			error : function(){
				$('#alertBox').show();
				$('#alertBox').text("Something Went Wrong");
				$(this).removeAttr("disabled");
			}, statusCode: {
		        400: function(responseJson) {
		        	$('#alertBox').show();
					$('#alertBox').text(responseJson.responseJSON.errors[0].field+" - "+responseJson.responseJSON.errors[0].defaultMessage);
					$('#save').removeAttr("disabled");
		          }
		        }
		});

	});
	$('#role','#psId','#domain','#name','#email').change(function(){
		$('.alert').hide();
		$('.alert').text("");
	});
		
	$('#manageUserBtn').click(function() {
		$('#userTable').DataTable().ajax.reload();
	});
	$('#createUserBtn').click(function() {
		initCreateForm();
		$('#alertBoxSuccess').hide();
		$('#alertBoxSuccess').text("");
		
	});
	
	 
	 $("#userTable").on("click", ".edit", function(){
		$('#dataTable').hide();
		$('#edit-form').show();
		var userId = $(this).attr("userId");
		var psId = $(this).attr("psId");
		var userName = $(this).attr("userName");
		var userDomain = $(this).attr("userDomain");
		var userEmail = $(this).attr("userEmail");
		var roleId = $(this).attr("roleId");
		$('#userIdEdit').val(userId);
		$('#psIdEdit').val(psId);
		$('#psIdEdit').attr('disabled','disabled');
		$('#domainEdit').val(userDomain);
		$('#nameEdit').val(userName);
		$('#emailEdit').val(userEmail);
		$('#roleEdit').val(roleId);
		$('#roleIdEdit').val(roleId);
	});
	 
	 $("#update").on("click", function(){
			$(this).attr("disabled","disabled");
			var userId = $('#userIdEdit').val();
			var oldRoleId = $('#roleIdEdit').val();
			var domain = $('#domainEdit').val();
			var name = $('#nameEdit').val();
			var email = $('#emailEdit').val();
			var newRole = $('#roleEdit').val();
			var updateJson = {
					"oldRoleId": oldRoleId, 
					"newRoleId": newRole,
					"userName" : name,
					"email" : email,
					"userDomain" : domain,
					"userId" : userId
			};
			
		$.ajax({
			url : 'updateuser',
			type : 'POST',
			data : updateJson,
			success : function() {
				$('#alertBoxSuccessEdit').show();
				$('#alertBoxSuccessEdit').text("Successfully saved");
				$(this).removeAttr("disabled");
				$('#userTable').DataTable().ajax.reload();
				setTimeout(function () {
					
					$('#alertBoxSuccessEdit').hide();
					$('#alertBoxSuccessEdit').text("");
					$('#dataTable').show();
					$('#edit-form').hide();
                }, 2500);
			},
			error : function(){
				$('#alertBoxEdit').show();
				$('#alertBoxEdit').text("Something Went Wrong");
				$(this).removeAttr("disabled");
				
			}, statusCode: {
		        400: function(responseJson) {
		        	$('#alertBoxEdit').show();
					$('#alertBoxEdit').text(responseJson.responseJSON.errors[0].field+" - "+responseJson.responseJSON.errors[0].defaultMessage);
					$('#update').removeAttr("disabled");
		          }
		        }
		});
	});
});

function userTable(){
	$('#userTable').DataTable( {
        "ajax": 'listusers',
        "columns": [
            { "data": "userName" },
            { "data": "userDomain" },
            { "data": "userEmail" },
            { "data": "psId" },
            { "data": "roleName" },
            { "data": "userUpdatedBy" },
            { "data": "createdOn" },
            { "data": "updatedOn"},
            { "data" : null,"render": function ( data, type, row ) {
                return '<button class="btn btn-sm btn-primary edit" psId="'+data.psId+'" roleId="'+data.roleId+'" userId="'+data.userId+'" userName="'+data.userName+'" userDomain="'+data.userDomain+'" userEmail="'+data.userEmail+'">Edit</button>';
            }}
        ]
    } );
}
function initCreateForm(){
	$('#save').removeAttr("disabled");
	$('#role').val("");
	$('#psId').val("");
	$('#domain').val("");
	$('#name').val("");
	$('#email').val("");
	$(".fa-validate").hide();
	$('#validate').show();
	$("#psId").removeAttr("disabled");
	$('#edit').hide();
	$('#validationMsg').text("");
}

function listroles() {
	$.ajax({
		url : 'listroles',
		type : 'GET',
		dataType : 'json',
		success : function(json) {
			$.each(json, function(i, value) {
				$('#role').append($('<option>').text(value.roleName).attr('value', value.roleId));
				$('#roleEdit').append($('<option>').text(value.roleName).attr('value', value.roleId));
			});
		}
	});
}
