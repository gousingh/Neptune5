/**
 * 
 */

//  Fetch model type and name according for compare page

$("#modelTypeDS").on("change", function(){
		var optionSelected = $("#modelTypeDS option:selected").val();
		if(optionSelected != "SelectModelType"){  
			populateModelNameDS(optionSelected);
			
		}
	});
	
	$("#modelTypeBZ").on("change", function(){
		var optionSelected = $("#modelTypeBZ option:selected").val();
		if(optionSelected != "SelectModelType"){  
			populateModelNameBZ(optionSelected);
			
		}
	});
	
	
	function populateModelTypDS(){
		var data = '${modelTypeDS}';
		if(data != null || data != ""){
			var parsedData = JSON.parse(data);
			var html = "";
			$.each(parsedData,function(k,v){
				$.each(v,function(key,value){				
					html += "<option value='"+value+"'>"+value+"</option>";
				});
			});
			$("#modelTypeDS").append(html);
		}
		
	}

	function populateModelTypBZ(){
		var data = '${modelTypeBZ}';
		if(data != null || data != ""){
			var parsedData = JSON.parse(data);
			var html = "";
			$.each(parsedData,function(k,v){
				$.each(v,function(key,value){				
					html += "<option value='"+value+"'>"+value+"</option>";
				});
			});
			$("#modelTypeBZ").append(html);
		}
		
	}

	function populateModelNameDS(modelType){
		$("#modelNameDS").empty().append('<option value="SelectName" selected>Select Model Name...</option>');
			$("#loading").show();  //load.gif 

		$.ajax({
			type : "GET",
			url : "${pageContext.request.contextPath}/getModelNmDS",
			data : {
				modelType : modelType // parameters  controller var:parameter to ajax
			},
			cache : false,
			success : function(resp) {
				if(resp != null || resp != ""){
					var parsedData = JSON.parse(resp);
					var html = "";
					$.each(parsedData,function(k,v){

						$.each(v,function(key,value){ //iterating arraylist
							html += "<option value='"+value+"'>"+value+"</option>";
						});
					});
					$("#modelNameDS").append(html);
					//$("#m1").append(html);
						$("#loading").hide();
				}
				
			},
			error: function(){
				$("#loading").hide();
			}
		});
	}

	function populateModelNameBZ(modelType){
		$("#modelNameBZ").empty().append('<option value="SelectName" selected>Select Model Name...</option>');
		//$("#m1").empty().append('<option value="SelectName" selected>Select Model Name...</option>');
			$("#loading").show();  //load.gif 

		$.ajax({
			type : "GET",
			url : "${pageContext.request.contextPath}/getModelNmBZ",
			data : {
				modelType : modelType // parameters  controller var:parameter to ajax
			},
			cache : false,
			success : function(resp) {
				if(resp != null || resp != ""){
					var parsedData = JSON.parse(resp);
					var html = "";
					$.each(parsedData,function(k,v){

						$.each(v,function(key,value){ //iterating arraylist
							html += "<option value='"+value+"'>"+value+"</option>";
						});
					});
					$("#modelNameBZ").append(html);
					//$("#m1").append(html);
						$("#loading").hide();
				}
				
			},
			error: function(){
				$("#loading").hide();
			}
		});
	}

	function populateTables(datasetName){
		$("#tableList").empty().append('<option value="selectTable" selected>Select Table ...</option>');
		$(".preloader").show();
		$.ajax({
			type : "POST",
			url : "${pageContext.request.contextPath}/getTables",
			data : {
				datasetName : datasetName
			},
			cache : false,
			success : function(resp) {
				if(resp != null || resp != ""){
					var parsedData = JSON.parse(resp);
					var html = "";
					$.each(parsedData,function(k,v){
						$.each(v,function(key,value){
							html += "<option value='"+value+"'>"+value+"</option>";
						});
					});
					$("#tableList0").append(html);
					$("#tableList1").append(html);
					$("#tableList2").append(html);
					$("#tableList3").append(html);
					$(".preloader").hide();
				}
				
			},
			error: function(){
				$(".preloader").hide();
			}
		});
	}

	function populateDatasets(){
		$("#datasetList").empty().append('<option value="selectDataset" selected>Select Dataset ...</option>');
		var data = '${datasetList}';
		if(data != null || data != ""){
			var parsedData = JSON.parse(data);
			var html = "";
			$.each(parsedData,function(k,v){
				$.each(v,function(key,value){
					//alert(key+"::"+value)
					html += "<option value='"+value+"'>"+value+"</option>";
				});
			});
			$("#datasetList").append(html);
			$("#ds").append(html);
		}
	}

	


// code ends
