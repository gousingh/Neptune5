/**
 * 
 */


$("#model").on("change", function(){
		var optionSelected = $("#model option:selected").val();
		if(optionSelected != "SelectModelType"){  
			populateModelName(optionSelected);
			
		}
	});
	$("#m").on("change", function(){
		var nameOptionSelected = $("#m option:selected").val();
		if(nameOptionSelected != "SelectName"){ 
			var typeOptionSelected = $("#model option:selected").val();
			populateModelVer(typeOptionSelected,nameOptionSelected);
		}
	});
	$("#model1").on("change", function(){
		var optionSelected = $("#model1 option:selected").val();
		if(optionSelected != "SelectModelType"){  
			populateModelName(optionSelected);
			
		}
	});
	$("#m1").on("change", function(){
		var nameOptionSelected = $("#m1 option:selected").val();
		if(nameOptionSelected != "SelectName"){ 
			var typeOptionSelected = $("#model1 option:selected").val();
			populateModelVer(typeOptionSelected,nameOptionSelected);
		}
	});
	$('.tabs .tab-links a').on('click', function(e) {
		var currentAttrValue = $(this).attr('href');
		
$('.tabs ' + currentAttrValue).show().siblings().hide();
	
		$(this).parent('li').addClass('active').siblings().removeClass('active');

		e.preventDefault();
		
	});

function populateModelTyp(){
	var data = '${modelType}';
	if(data != null || data != ""){
		var parsedData = JSON.parse(data);
		var html = "";
		$.each(parsedData,function(k,v){
			$.each(v,function(key,value){				
				html += "<option value='"+value+"'>"+value+"</option>";
			});
		});
		$("#model").append(html);
		$("#model1").append(html);	
		
//			$("#model").append("appended data");
		
	}
	
}

	

function populateModelName(modelType){
	$("#m").empty().append('<option value="SelectName" selected>Select Model Name...</option>');
	$("#m1").empty().append('<option value="SelectName" selected>Select Model Name...</option>');
		$("#loading").show();  //load.gif 

	$.ajax({
		type : "GET",
		url : "${pageContext.request.contextPath}/getModelNm",
		data : {
			modelType : modelType // parameters  controller var:parameter to ajax
		},
		cache : false,
		success : function(resp) {
			if(resp != null || resp != ""){
				var parsedData = JSON.parse(resp);
				var html = "";
				$.each(parsedData,function(k,v){

					$.each(v,function(key,value){ //iterating arraylist
						html += "<option value='"+value+"'>"+value+"</option>";
					});
				});
				$("#m").append(html);
				$("#m1").append(html);
					$("#loading").hide();
			}
			
		},
		error: function(){
			$("#loading").hide();
		}
	});
}

function populateModelVer(modelType,modelName){
	$("#modelVr").empty().append('<option value="SelectVersion" selected>Select Model Version...</option>');
	$("#modelVr1").empty().append('<option value="SelectVersion" selected>Select Model Version...</option>');
		$("#loading").show();  //load.gif 

	$.ajax({
		type : "GET",
		url : "${pageContext.request.contextPath}/getModelVr",
		data : {
			modelType : modelType,
			modelName : modelName
		},
		cache : false,
		success : function(resp) {
			if(resp != null || resp != ""){
				var parsedData = JSON.parse(resp);
				var html = "";
				$.each(parsedData,function(k,v){
					$.each(v,function(key,value){ //iterating arraylist
						html += "<option value='"+value+"'>"+value+"</option>";
					});
				});
				$("#modelVr").append(html);
				$("#modelVr1").append(html);
				
					$("#loading").hide();;
			}
			
		},
		error: function(){
			$("#loading").hide();
		}
	});
}


function populateTables(datasetName){
	$("#tableList").empty().append('<option value="selectTable" selected>Select Table ...</option>');
	$(".preloader").show();
	$.ajax({
		type : "POST",
		url : "${pageContext.request.contextPath}/getTables",
		data : {
			datasetName : datasetName
		},
		cache : false,
		success : function(resp) {
			if(resp != null || resp != ""){
				var parsedData = JSON.parse(resp);
				var html = "";
				$.each(parsedData,function(k,v){
					$.each(v,function(key,value){
						html += "<option value='"+value+"'>"+value+"</option>";
					});
				});
				$("#tableList").append(html);
				$(".preloader").hide();
			}
			
		},
		error: function(){
			$(".preloader").hide();
		}
	});
}

function populateDatasets(){
	$("#datasetList").empty().append('<option value="selectDataset" selected>Select Dataset ...</option>');
	var data = '${datasetList}';
	if(data != null || data != ""){
		var parsedData = JSON.parse(data);
		var html = "";
		$.each(parsedData,function(k,v){
			$.each(v,function(key,value){
				//alert(key+"::"+value)
				html += "<option value='"+value+"'>"+value+"</option>";
			});
		});
		$("#datasetList").append(html);
		$("#ds").append(html);
	}
}

function populateSchema(datasetName, tableName){
	$(".preloader").show();
	$.ajax({
		type : "POST",
		url : "${pageContext.request.contextPath}/getSchema",
		data : {
			datasetName : datasetName,
			tableName : tableName
		},
		cache : false,
		success : function(resp) {
			console.log(resp);
			if(resp != null || resp != ""){
				$("#schemaTable").show();
					var parsedData = JSON.parse(resp);
					var html = "";
					$.each(parsedData,function(k,v){
						var count = 1;
						$.each(v,function(key,value){
							var array = value.split(",");
							html += "<tr><td>"+count+"</td><td>"+array[0]+"</td><td>"+array[1]+"</td><td>"+array[2]+"</td><td>"+array[3]+"</td></tr>";
							count++;
						});
					}); 
					console.log(html);
				$("#schemaTable tbody").html("");
				$("#schemaTable tbody").append(html);
				$(".preloader").hide();
			}
			
		},
		error: function(){
			$("#.preloader").hide();
		}
	});
}
